function [] = setupPD1_stereo

%function [] = setupPD1_stereo
% set up PD1 for single source output through HRTFs
% and single source AtoD
% under construction

global REC_INFO
global FN

% get XB lock
if(S232('XBlock',100, 0)==0)
   disp('FAILED to get XBlock in SetupPD1stereo');
   return;
else
%   disp('XBlock in SetupPD1stereo');
end

% get AP lock
if(S232('APlock',100, 0)==0)
   disp('FAILED to get APlock in SetupPD1stereo');
   return;
else
%   disp('APlock in SetupPD1stereo');
end

% clear PD1
s232('PD1clear', 1);

% specify conversion params
s232('PD1srate', 1,REC_INFO.stim_samp_period);
s232('PD1nstrms', 1,2,1);			% 2 input & 1 output buffer

% setup 2 DSPs
s232('PD1resetDSP', 1,255);
s232('dropall');
s232('PD1clrsched', 1);

% DSP0 and DSP2 to DAC0  (PD1addmult,din,sources,scales,chans,destinations)
scales = [1 1];
s232('PD1addmult', 1,[S232('DSPout',0) S232('DSPout',2)],scales,2,S232('DAC',0));	

% DSP1 and DSP3 to DAC1
scales = [1 1];
s232('PD1addmult', 1,[S232('DSPout',1) S232('DSPout',3)],scales,2,S232('DAC',1));	

% IREG0 to DSP0 & DSP1
s232('PD1addsimp', 1,S232('IREG',0),S232('DSPin',0));
s232('PD1addsimp', 1,S232('IREG',0),S232('DSPin',1));
% IB0 to IREG0
s232('PD1specIB', 1,S232('IB',0),S232('IREG',0));		

% IREG1 to DSP2 & DSP3
s232('PD1addsimp', 1,S232('IREG',1),S232('DSPin',2));
s232('PD1addsimp', 1,S232('IREG',1),S232('DSPin',3));
% IB1 to IREG1
s232('PD1specIB', 1,S232('IB',1),S232('IREG',1));		

% the outbound data stream from ADC0 to OB0
s232('PD1specOB', 1,S232('OB',0),S232('ADC',0));

loadSound(FN.sound1,1);				% loadSound1
loadSound(FN.sound2,2);				% loadSound2

% other options under development:
%loadtone;				% testing with a tone
%loadSound_ABS;		% load sound for pupil dilation exp
%loadMATLABarray;		% testing loading MATLAB array

buildFiltbufs;							% builds 2 filter buffers for HRTF coefs

if (REC_INFO.recordAD)
   buildRecBuf;						% build Recording & Decimation Buffers
end

build2PlaySeq;							% build play sequences & play spec list

%unlock
S232('APunlock',0);
%disp('APunlock in Setup');
S232('XBunlock',0);
%disp('XBunlock in Setup');