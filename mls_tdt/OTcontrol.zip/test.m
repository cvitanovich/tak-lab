%Set sequences
S232('seqplay',BUF.playspec);
S232('seqrecord',BUF.recordspec);

%Initialize and Trigger the PD1
S232('PD1clear',din);
S232('PD1srate',din,REC_INFO.stim_samp_period);
S232('PD1npts',din,REC_INFO.npts_total_play);
S232('PD1mode',din,15); %15 = DUALDAC + DUALADC, hex 3 + hex C
S232('PD1arm',din);
S232('PD1go',din);

%Collect Data - Main Loop for Double Buffering
cycle_count = 0;
while(S232('PD1status',din) ~= 0)
   
   %Wait for first set of buffers to finish filling
   while(S232('PD1status',din) ~= 0 &...
         S232('recseg',1) == BUF.chan1record1 &...
         S232('recseg',2) == BUF.chan2record1)
   end
      
   %Wait for second set of buffers to finish filling
   while(S232('PD1status',din) ~= 0 &...
         S232('recseg',1) == BUF.chan1record2 &...
         S232('recseg',2) == BUF.chan2record2)
   end
  
   cycle_count = cycle_count + 1;
end %end WHILE loop for collecting data
