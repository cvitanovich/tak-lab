function [err] = readScriptSrc

%function [err] = readScriptSrc
% read next sourcesection from script file
% places sound file names into FN and
% adjusts QUES.numberOfSoundFiles

global QUES
global FN
err = 0;

% check to be sure file is open
if QUES.scriptfileopen <= 0
   fid = fopen(FN.script, 'r');
   if fid <1
   	err = -1;
  		warning('Cannot open file in readscript');
   end
   QUES.scriptfileopen = fid;
else
   fid = QUES.scriptfileopen;
end

% read to next source section
line = '0';
while line ~= -1
   line = fgets(fid);
   if line(1) == '#';
   	if line(1:4) == '#sou'		break;	end   
   end
end

if feof(fid) 
   QUES.scriptEOF = 1;
	return;   
end

% read source section from script file
if line(1:8) == '#sources'
   line = fgets(fid);
   [m,n] = size(line);
   FN.sound1 = line(1:n-2);
   QUES.numberofsoundfiles = 1;
   loc = ftell(fid);
   line = fgets(fid);
   if line(1) ~= '#'
      [m,n] = size(line);
      FN.sound2 = line(1:n-2);
      QUES.numberofsoundfiles = 2;
      loc = ftell(fid);
   end
end

if feof(fid) QUES.scriptEOF = 1;	end

if (fseek(fid,loc,'bof') < 0)			% return to last #
   err = -1;
   warning('FAILED to return to last line in ReadScriptSrc');
end
