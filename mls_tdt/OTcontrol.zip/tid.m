%get external variables
DSPout(1) = s232('PD1export','xDSPOUT',0);
DSPout(2) = s232('PD1export','xDSPOUT',1);
DSPout(3) = s232('PD1export','xDSPOUT',2);
DSPout(4) = s232('PD1export','xDSPOUT',3);

