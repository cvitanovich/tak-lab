function [] = init_tdt;

%function [] = init_tdt(din, trig_mode)
% initialize all SystemII hardware

if(S232('S2init',0 ,'INIT_SECONDARY',1000)==0)
   disp('FAILED to initialize a secondary process');
   return;
else
   disp('Initialized secondary process');
end

if(S232('APlock',100, 0 )==0)
   disp('FAILED to get AP lock for initialization');
   return;
end
if(S232('XBlock',100, 0 )==0)
   disp('FAILED to get XB lock for initialization');
   S232('APunlock',0 );                         
   disp('AP unlock');
   return;
end

PD1FixBugNew(1);   

S232('XBunlock',0);
S232('APunlock',0);
