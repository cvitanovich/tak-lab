clear;
din = 1;

if(S232('S2init',0,'INIT_SECONDARY',1000)==0)
   disp('FAILED to initialize a secondary process');
   return;
else
   disp('Initialized secondary process');
end

if(S232('APlock',100, 0)==0)
   disp('FAILED to get AP lock for initialization');
   return;
else
   disp('AP lock');
end
if(S232('XBlock',100, 0)==0)
   disp('FAILED to get XB lock for initialization');
   S232('APunlock',0);                         
   disp('AP unlock');
   return;
else
   disp('XB lock');
end

%Init Buffers
N = 3000;
newN = 10*N;
PlaySpec = S232('_allot16',10); % Dana 1
RecSpec = S232('_allot16',10);  % Dama 2
PlaySeq1 = S232('_allot16',10); % Dana 3
PlaySeq2 = S232('_allot16',10); % Dana 4
RecSeq1 = S232('_allot16',10);  % Dana 5
RecSeq2 = S232('_allot16',10);  % Dana 6

Buf1aOut = S232('_allot16', newN); % Dana 7
Buf1bOut = S232('_allot16', newN); % Dana 8 
Buf1aIn = S232('_allot16', N);  % Dana 9
Buf1bIn = S232('_allot16', N);  % Dana 10

Buf2aOut = S232('_allot16', newN); % Dana 11
Buf2bOut = S232('_allot16', newN); % Dana 12
Buf2aIn = S232('_allot16', N);  % Dana 13
Buf2bIn = S232('_allot16', N);  % Dana 14

% Build a play specification list
S232('dpush', 10);
S232('value', 0);
S232('make', 0, PlaySeq1);
S232('make', 1, PlaySeq2);
S232('qpop16', PlaySpec);

% Build a record specification list
S232('dpush', 10);
S232('value', 0.0);
S232('make', 0, RecSeq1);
S232('make', 1, RecSeq2);
S232('qpop16', RecSpec);

% play sequence
S232('dpush', 10);
S232('value', 0.0);
S232('make', 0, Buf1aOut);
S232('make', 1, 1);
%S232('make', 2, Buf1bOut);
%S232('make', 3, 1);
S232('qpop16', PlaySeq1);

S232('dpush', 10);
S232('value', 0.0);
S232('make', 0, Buf2aOut);  
S232('make', 1, 1);
%S232('make', 2, Buf2bOut);
%S232('make', 3, 1);
S232('qpop16', PlaySeq2);

% sequenced record
S232('dpush', 10);
S232('value', 0);
S232('make', 0, Buf1aIn);
S232('make', 1, 1);
S232('make', 2, Buf1bIn);
S232('make', 3, 1);
S232('qpop16', RecSeq1);

S232('dpush', 10);
S232('value', 0);
S232('make', 0, Buf2aIn); 
S232('make', 1, 1);
S232('make', 2, Buf2bIn);
S232('make', 3, 1);
S232('qpop16', RecSeq2);

% Initialize Buffers
S232('dpush', N);
S232('value', 0);
S232('dupn', 3);
S232('qpop16', Buf1aIn);
S232('qpop16', Buf1bIn);
S232('qpop16', Buf2aIn);
S232('qpop16', Buf2bIn);

S232('dpush', newN);
S232('tone', 100, 20);
S232('scale', 10000);  
S232('qpop16', Buf1aOut);
%S232('dpush', newN);
%S232('tone', 100, 20);
%S232('scale', 20000);
%S232('qpop16', Buf1bOut);

S232('dpush', newN);
S232('tone', 200, 20);
S232('scale', 10000);
S232('qpop16', Buf2aOut);
%S232('dpush', N);
%S232('tone', 200, 20);
%S232('scale', 20000);
%S232('qpop16', Buf2bOut);

% Init Device
s232('PD1clear', din);  
s232('PD1srate', din, 33.3333333333333);
s232('PD1mode', din, 15);
S232('PD1npts', 1, newN);

S232('seqplay', PlaySpec);
S232('seqrecord', RecSpec);

S232('PD1arm',din);
s232('PD1go',din);

DoSomething = 0;
cycles_a = 0;
cycles_b = 0;
while S232('PD1status',din)
   
   while(S232('PD1status',din) ~= 0 &...
         S232('recseg',1) == Buf1aIn &...
         S232('recseg',2) == Buf2aIn)
   end
      cycles_a = cycles_a + 1;
   
   while(S232('PD1status',din) ~= 0 &...
         S232('recseg',1) == Buf1bIn &...
         S232('recseg',2) == Buf2bIn)
   end   
      cycles_b = cycles_b + 1;
      
   DoSomething = DoSomething + 1;
end

disp('All points played and collected')
disp('Look at the buffers through the S232 Controller NewPlot Window') 
disp('The Input and Output Buffers should match')

pause
S232('deallot', PlaySpec);
S232('deallot', RecSpec);
S232('deallot', PlaySeq1);
S232('deallot', PlaySeq2);
S232('deallot', RecSeq1);
S232('deallot', RecSeq2);

S232('deallot', Buf1aOut);
S232('deallot', Buf1bOut);
S232('deallot', Buf1aIn);
S232('deallot', Buf1bIn);

S232('deallot', Buf2aOut);
S232('deallot', Buf2bOut); 
S232('deallot', Buf2aIn);
S232('deallot', Buf2bIn);

S232('XBunlock',0);
S232('APunlock',0);
S232('S2close'); 