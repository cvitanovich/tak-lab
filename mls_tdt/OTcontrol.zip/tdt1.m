% very slimmed down version to duplicate problem with DAC

din = 1;
MIItrig = 0;
sndpts = 3000;
zpts = 255;

if(S232('S2init',0,'INIT_SECONDARY',1000)==0)
   disp('FAILED to initialize a secondary process');
   return;
else
   disp('Initialized secondary process');
end

if(S232('APlock',100, 0)==0)
   disp('FAILED to get AP lock for initialization');
   return;
else
   disp('AP lock');
end
if(S232('XBlock',100, 0)==0)
   disp('FAILED to get XB lock for initialization');
   S232('APunlock',0);
   disp('AP unlock');
   return;
else
   disp('XB lock');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%% PD1FixBugNew
DUALADC = s232('PD1export','DUALADC',0);

s232('PD1mode',din,DUALADC);
s232('PD1npts',din, 600);
s232('PD1srate',din, 200);
s232('PD1arm',din);

if MIItrig
   s232('PD1strig',din);
   m101x(8,1,3,0);
else
   s232('PD1go',din); 
   while S232('PD1status',din)
      date;
   end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
%%%%%%% setupPD1_mono

% clear PD1
s232('PD1clear', din);

% specify conversion params
s232('PD1srate', din, 33.3333);
s232('PD1nstrms', din, 1,1);			% 1 input & 1 output buffer

% setup 2 DSPs
s232('PD1resetDSP', din,255);
s232('dropall');
s232('PD1clrsched', din);

% for testing only
%s232('PD1addsimp', din,S232('IREG',0),S232('DAC',0));
%s232('PD1addsimp', din,S232('IREG',0),S232('DAC',1));

% use DSPs
s232('PD1addsimp', 1,S232('DSPout',0),S232('DAC',0));	% DSP0 to DAC0
s232('PD1addsimp', 1,S232('DSPout',1),S232('DAC',1));	% DSP1 to DAC1

s232('PD1addsimp', 1,S232('IREG',0),S232('DSPin',0));	% IREG0 to DSP0
s232('PD1addsimp', 1,S232('IREG',0),S232('DSPin',1));	% IREG0 to DSP1

s232('PD1specIB', din,S232('IB',0),S232('IREG',0));			% IB0 to IREG0

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%loadtone;

% make 3000 pt tone
S232('dpush',sndpts);
S232('tone',50,33.3333);
S232('scale', 30000);
   
% set the number of points to play
size = S232('topsize');
S232('PD1npts', 1, size+zpts);

% Initialize & fill DAMA for IB[0] (sound1)
BUF1 = S232('_allot16',3000);
S232('qpop16',BUF1);

% load ZBUF with zpts zeros
S232('dpush',zpts);
S232('value',0);
ZBUF = S232('_allot16',255);
S232('qpop16',ZBUF);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% build1PlaySeq;		% build play sequence #1 & play spec list

% build 1st play sequence
S232('dpush', 10);
S232('value',0);
S232('make',0, BUF1);
S232('make',1, 1);
S232('make',2, ZBUF);
S232('make',3, 1);
S232('make',4, 0);
seq1 = S232('_allot16',10);
S232('qpop16',seq1);

% Build a play specification list
S232('dpush',10);
S232('value',0);
S232('make',0, seq1);
S232('make',1, 0);
playspec = S232('_allot16',10);
S232('qpop16', playspec);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%% preload unitary HRTFs
% load left ear coefs
filt1 = [1; zeros(254,1)];
S232('dpush',255);
S232('push16',filt1,255);
S232('scale',1/30000);		%%%XXX
S232('PreLoadRaw',1,S232('DSPid',0)','MONO','STACK','','',.2,.2,1);
% load right ear coefs
filt2 = [zeros(254,1); 1];
S232('dpush',255);
S232('push16',filt2,255);
S232('scale',1/30000);		%%%XXX
S232('PreLoadRaw',1,S232('DSPid',1),'MONO','STACK','','',.2,.2,1);

disp('<CR> to for each of 10 reps');		pause;

for i = 1:10
   t0 = rem(now,1);
   S232('seqplay',playspec);
   S232('PD1arm',din);
   S232('pfireall');
   S232('PD1strig',din);
   if MIItrig
      mii_trig(0);
   else
      s232('PD1go',din);
      while S232('PD1status',din)
         date;
      end
   end
   
	pause;   
end


S232('XBunlock',0);
S232('APunlock',0);
S232('S2close');
disp('AP & XB unlocked, S2 closed');