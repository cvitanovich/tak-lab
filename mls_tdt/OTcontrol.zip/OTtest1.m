
%Allot buffers and make new noise if the settings have changed
   S232('trash');
   
   %Make 1 ms of silence and put into BUF.zeros
   S232('dpush',30);
   S232('value',0.0);
  	Bzeros = S232('_allot16',30);
   S232('qpop16',Bzeros);
   
   %Make SOUNDS   
   [temp,bpsound] = whnoise(2000,11000,30000,100/1000);
   bpsound = 1000*bpsound'; %MUST BE A ROW VECTOR!!!!
   % put array on stack
   S232('dpush',length(bpsound));
	S232('push16',bpsound,length(bpsound));

	%scale & duplicate
	bufMag = max([S232('maxval') abs(S232('minval'))]);
	if (bufMag > 0.0)
		S232('scale', 32000/bufMag);
   end
   S232('qwind',2,REC_INFO.stim_samp_period);
   S232('qdup');
   
   % Initialize and fill DAMA for sound1
	if (isempty(Bsound1))
      Bsound1 = S232('_allot16',length(bpsound));
   end
   S232('qpop16',Bsound1);
   
   % Initialize Recording Buffers
   Bchan1 = S232('_allot16',1000);
   Bchan2 = S232('_allot16',1000);
   end
	S232('dpush', 1000);
	S232('value', 0);
	S232('dupn', 1);
	S232('qpop16', Bchan1);
	S232('qpop16', Bchan2);
   
   %Build PLAY sequence for Channel 1
   S232('dpush',10);
   S232('value',0);
   S232('make',0,Bzeros)
   S232('make',1,1000);
   S232('make',2,Bsound1);
   S232('make',3,1);
   S232('make',4,Bzeros);
   S232('make',5,5000);
   Bplayseq1 = S232('_allot16',10);
   S232('qpop16',Bplayseq1);
      
   %Build PLAY specification List for 1-Channel Play
   S232('dpush',10);
   S232('value',0);
   S232('make',0,Bplayseq1);
  	Bplayspec = S232('_allot16',10);
   S232('qpop16',Bplayspec);

   %Build RECORD Sequence for Double Buffering 
   S232('dpush',10);
   S232('value',0);
   S232('make',0,Bchan1);
   S232('make',1,1);
   S232('make',2,Bchan1B);
   S232('make',3,1);
  	Brecseq1 = S232('_allot16',10);
   S232('qpop16',Brecseq1);
   
%Initialize the PD1
S232('PD1clear',din);
S232('PD1fixbug',din);
S232('PD1srate',din,1/30000);
S232('PD1mode',din,13); 			%15 = DUALDAC + DUALADC, hex 3 + hex C
											%13 = DAC1 + DUALADC, hex 1 + hec C
S232('PD1npts',din,REC_INFO.npts_total_play);

%Set sequences
S232('seqplay',BUF.playspec);
S232('seqrecord',BUF.recordspec);

%Arm & Trigger the PD1
S232('PD1arm',din);
S232('PD1go',din);

%trigger from m101 chan 0
%m101x(C_.DATA,M_.BIT,M_.PULSE,0);
%delay_msec(500);

%Collect Data - Main Loop for Double Buffering
cycle_count = 0;
while S232('PD1status',din)
   
   %Wait for first buffers to finish loading
   while(S232('recseg',1) == BUF.chan1recordA &...
         S232('recseg',2) == BUF.chan2recordA)
   end
      
   S232('qpush16',BUF.chan1recordA);
   Vx = S232('whatis',S232('topsize')-1);
   Vx = gain_horiz*volt_mult*Vx/(K*32000);
     
   S232('qpush16',BUF.chan2recordA);
   Vy = S232('whatis',S232('topsize')-1);
   Vy = gain_horiz*volt_mult*Vy/(K*32000);
      
   if(Vx >= -1 & Vx <= 1 & Vy >= -1 & Vy <=1)
      AZ = (180/pi)*asin(Vx);
      EL = (180/pi)*asin(Vy);
   end
   
   S232('dropall');
   
   %plot datapts
   plot(AZ,EL,plotsymbol);
   
   %Wait for second buffers to finish loading
   %S232('PD1status',din) &...

   while(S232('recseg',1) == BUF.chan1recordB &...
         S232('recseg',2) == BUF.chan2recordB)
   end
   
   S232('qpush16',BUF.chan1recordB);
   Vx = S232('whatis',S232('topsize')-1);
   Vx = gain_horiz*volt_mult*Vx/(K*32000);
     
   S232('qpush16',BUF.chan2recordB);
   Vy = S232('whatis',S232('topsize')-1);
   Vy = gain_horiz*volt_mult*Vy/(K*32000);
      
   if(Vx >= -1 & Vx <= 1 & Vy >= -1 & Vy <=1)
      AZ = (180/pi)*asin(Vx);
      EL = (180/pi)*asin(Vy);
   end
   
   plot(AZ,EL,plotsymbol);
   
   S232('dropall');
   
   %plot datapts
   plot(AZ,EL,'g.');

   
   cycle_count = cycle_count + 1;
end 					%end WHILE loop for collecting data

cycle_count
mtflag = 1;
delay_msec(1000);
axes(h_axes);
hold off
return