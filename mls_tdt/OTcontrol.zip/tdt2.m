% very slimmed down version
% for stereo

din = 1;
MIItrig = 0;
sndpts = 3000;
zpts = 255;

if(S232('S2init',0,'INIT_SECONDARY',1000)==0)
   disp('FAILED to initialize a secondary process');
   return;
else
   disp('Initialized secondary process');
end

if(S232('APlock',100, 0)==0)
   disp('FAILED to get AP lock for initialization');
   return;
else
   disp('AP lock');
end
if(S232('XBlock',100, 0)==0)
   disp('FAILED to get XB lock for initialization');
   S232('APunlock',0);
   disp('AP unlock');
   return;
else
   disp('XB lock');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%% PD1FixBugNew
DUALADC = s232('PD1export','DUALADC',0);

s232('PD1mode', din, DUALADC);
s232('PD1npts', din,600);
s232('PD1srate', din,200);
s232('PD1arm', din);

if MIItrig
   s232('PD1strig', din);
   m101x(8,1,3,0);
else
   s232('PD1go', din); 
   while S232('PD1status', din)
      date;
   end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
%%%%%%% setupPD1_stereo

% clear PD1
s232('PD1clear', din);

% specify conversion params
s232('PD1srate', din, 33.3333);
s232('PD1nstrms', din, 2, 1);			% 2 input & 1 output buffer

% setup 2 DSPs
s232('PD1resetDSP', din, 255);
s232('dropall');
s232('PD1clrsched', din);

% DSP0 and DSP2 to DAC0  (PD1addmult,din,sources,scales,nsrcs,destination)
s232('PD1addmult', 1,[S232('DSPout',0) S232('DSPout',2)],[1 1],2,S232('DAC',0));	

% DSP1 and DSP3 to DAC1
s232('PD1addmult', 1,[S232('DSPout',1) S232('DSPout',3)],[1 1],2,S232('DAC',1));	

% IREG0 to DSP0 & DSP1
s232('PD1addsimp', 1,S232('IREG',0),S232('DSPin',0));
s232('PD1addsimp', 1,S232('IREG',0),S232('DSPin',1));
% IB0 to IREG0
s232('PD1specIB', 1,S232('IB',0),S232('IREG',0));		

% IREG1 to DSP2 & DSP3
s232('PD1addsimp', 1,S232('IREG',1),S232('DSPin',2));
s232('PD1addsimp', 1,S232('IREG',1),S232('DSPin',3));
% IB1 to IREG1
s232('PD1specIB', 1,S232('IB',1),S232('IREG',1));		

% the outbound data stream from ADC0 to OB0
s232('PD1specOB', 1,S232('OB', 0),S232('ADC', 0));

%%%%%%%%%%%%%%%% build zeros buffer
S232('dpush', zpts);
S232('value', 0);
ZBUF = S232('_allot16', zpts);
S232('qpop16', ZBUF);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%loadtone to BUF1;
% make 3000 pt tone
S232('dpush', sndpts);
S232('tone', 50, 33.3333);
S232('scale', 10000);
   
% Initialize & fill DAMA for IB[0] (sound1)
BUF1 = S232('_allot16', sndpts);
S232('qpop16',BUF1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%loadtone to BUF2;

% make 3000 pt tone
S232('dpush', sndpts);
S232('tone', 100, 33.3333);
S232('scale', 10000);
   
% Initialize & fill DAMA for IB[1] (sound2)
BUF2 = S232('_allot16', sndpts);
S232('qpop16', BUF2);

% set the number of points to play
S232('PD1npts', 1, sndpts + zpts);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% build2PlaySeq;		% build play sequence #1 & #2 & play spec list

% build 1st play sequence
S232('dpush', 10);
S232('value',0);
S232('make',0, BUF1);
S232('make',1, 1);
S232('make',2, ZBUF);
S232('make',3,1);
S232('make',4,0);
seq1 = S232('_allot16',10);
S232('qpop16',seq1);

% build 2nd play sequence
S232('dpush', 10);
S232('value',0);
S232('make',0, BUF2);
S232('make',1, 1);
S232('make',2, ZBUF);
S232('make',3, 1);
S232('make',4, 0);
seq2 = S232('_allot16',10);
S232('qpop16',seq2);

% Build a play specification list
S232('dpush',10);
S232('value',0);
S232('make',0, seq1);
S232('make',1, seq2);
S232('make',2, 0);
playspec = S232('_allot16',10);
S232('qpop16', playspec);

%%%%%%%%%%%%%%%%%%%%%%%% preload unitary HRTFs
% load left ear coefs
filt1 = [1; zeros(254,1)];
S232('dpush', 255);
S232('push16', filt1, 255);
S232('scale', 1/30000);		%%%XXX
S232('PreLoadRaw',1,S232('DSPid',0)','MONO','STACK','','',.2,.2,1);
% load right ear coefs
filt2 = [zeros(254,1); 1];
S232('dpush', 255);
S232('push16', filt2, 255);
S232('scale', 1/30000);		%%%XXX
S232('PreLoadRaw',1,S232('DSPid',1),'MONO','STACK','','',.2,.2,1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp('<CR> to for each of 10 reps');		pause;

for i = 1:10
   t0 = rem(now,1);
   S232('seqplay',playspec);
   S232('PD1arm',din);
   S232('pfireall');
   S232('PD1strig',din);
   if MIItrig
      mii_trig(0);
   else
      s232('PD1go',din);
      while S232('PD1status',din)
         date;
      end
   end   
	pause;   
end


S232('XBunlock',0);
S232('APunlock',0);
S232('S2close');
disp('AP & XB unlocked, S2 closed');