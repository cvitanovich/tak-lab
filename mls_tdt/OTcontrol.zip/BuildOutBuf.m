function [OutBuf,DecBuf] = buildOutBuf(OutBuf,DecBuf)

%function [] = buildRecBuf()
% build recording and decimation buffers

% The RecordBuf will be used to record the AtoD data.
% The DecimateBuf will be used to store the
% decimated data before writing the data to disk.
% Decimation is necessary since the playing and
% recording must be done at the same rate.
% To manage a different recording rate, the data
% buffer will be decimated after the data has
% been collected. Decimation occurs at 1 / (2 ^ DecimationFactor).

global REC_INFO;
global BUF
global QUES

% get AP lock
if(S232('APlock',100, 0)==0)
   disp('No APlock in BuildRecBuf');
   return;
else
%   disp('APlock in BuildRecBuf');
end

% reserve space on the stack
S232('dropall');
RecBufSize = REC_INFO.npts_total_play;
S232('dpush',RecBufSize);
   
% check here for proper buffer size
size = S232('topsize');
if (size ~= RecBufSize)
   warning('Could not allocate recording buffer on stack' );
end
   
% fill AtoD recording buffer with all zeros
S232('value',0);
S232('qdup');
if (isempty(OutBuf))
	OutBuf = S232('_allot16',size);
end
S232('qpop16',OutBuf);

% fill decimate buffer with all zeros
% check here for proper buffer size
size = S232('topsize');
if (size ~= RecBufSize)
   warning('Could not allocate decimation buffer on stack' );
end

S232('decimate', REC_INFO.decimationfactor);
size = S232('topsize');
if ( isempty(DecBuf) )
   DecBuf = S232('_allot16',size);
end
   
S232('qpop16',DecBuf);

%unlock
S232('APunlock',0);
%disp('APunlock');
