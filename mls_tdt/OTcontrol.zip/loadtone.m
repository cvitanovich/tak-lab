function [] = loadtone

%function [] = loadtone
% for trouble shooting

global BUF
global REC_INFO

% get lock
S232('APlock',100, 0)

% make tone
S232('dpush',3000);
S232('tone',50,REC_INFO.stim_samp_period);
%S232('value',10000);

bufMag = max([S232('maxval') abs(S232('minval'))])
if (bufMag > 0.0)
	S232('scale', 32000/bufMag);
end
   
% set the number of points to play
size = S232('topsize');
S232('PD1npts', 1, size);
REC_INFO.npts_total_play = size;

% Initialize & fill DAMA for IB[0] (sound1)
if (isempty(BUF.sound1))
	BUF.sound1 = S232('_allot16',3000);
end
S232('qpop16',BUF.sound1);

%unlock
S232('APunlock',0);