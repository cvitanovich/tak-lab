function [err] = SetDefaults

%function [err] = setdefaults
% sets default values for system II experiments

global REC_INFO
global FN
global QUES

% set defaults:
err = 0;

REC_INFO.nreps				= 20;
REC_INFO.depth 			= 200;
% REC_INFO.npts_total_record	= 5000;
REC_INFO.decimationfactor	= 1;
REC_INFO.latten			= 60.0;
REC_INFO.ratten			= 60.0;
REC_INFO.recordAD			= 0;
REC_INFO.recordspikes	= 1;

FN.AD1		= 'd:\kip\AD.dat';
FN.spikes	= 'd:\kip\spikes.dat';
FN.script	= 'd:\kip\scripts\test1.scr';
FN.HRTF		= 'd:\kip\hrtfdata\ones.eq';
FN.sound1	= 'd:\kip\noisetc\rnd1_30.noi';
%FN.sound2	= 'd:\kip\noisetc\rnd1_30.noi';

QUES.usescriptfile			= 1;
QUES.usedoublepolar			= 1;
QUES.readscriptheader		= 0;
QUES.interstimulusgap 		= 100;
QUES.randomizestimuli		= 0;
QUES.restrictelevation		= 0;
QUES.elevationmin				= 0;
QUES.elevationmax				= 0;
QUES.elevationinc				= 0;
QUES.restrictazimuth			= 0;
QUES.azimuthmin				= 0;
QUES.azimuthmax				= 0;
QUES.azimuthinc				= 0;
QUES.useVCR						= 1;

