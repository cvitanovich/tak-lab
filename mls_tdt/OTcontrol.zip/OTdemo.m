function [temp1,temp2] = OTDemo()

%Script OTMonitor
init_tdt;
rec_buf_duration = 1;		%n * 512 pts per buffer
din = 1;
samp_per = 33;					%usec
num_mon_pts = 64*512;

S232('PA4atten',2,99);

%Allot buffers and make new noise if the settings have changed
   S232('trash');
	BUF = struct(...
   'playspec', [],...
   'recordspec', [],...
   'playseq1', [],...
   'playseq2', [],...
   'playseq3', [],...
   'recseq1', [],...
   'recseq2', [],...
   'sound1', [],...
   'sound2', [],...
   'sound3', [],...
   'zeros', [],...
   'chan1recordA', [],...
   'chan1recordB', [],...
   'chan2recordA', [],...
   'chan2recordB', [],...
	'outbuffer', [],...   
   'decimate', [],...
   'coef',  [],...
   'filter1', [],...
   'filter2', [],...
   'pre', [],...
   'post', []);
   
   %Make 1 ms of silence and put into BUF.zeros
   S232('dpush',512);
   S232('value',0.0);
	if (isempty(BUF.zeros))
   	BUF.zeros = S232('_allot16',512);
	end
   S232('qpop16',BUF.zeros);
   
   %Make Monitor Sound   
   [temp,stim] = whnoise(2000,11000,30000,0.1);
   stim = 1000*stim; 		% MUST BE A ROW VECTOR!!!!
   npts = length(stim);
   stim = [stim; zeros(4096-npts,1)]';
   
   % put array on stack
   S232('dpush',4096);
   S232('push16',stim,4096);

	%scale
	bufMag = max([S232('maxval') abs(S232('minval'))]);
	if (bufMag > 0.0)
		S232('scale', 32000/bufMag);
	end
   
   % Initialize and fill DAMA for IB[0] (sound1)
	if (isempty(BUF.sound3))
      BUF.sound3 = S232('_allot16',4096);
   end
   S232('qwind',2,samp_per);
   S232('qpop16',BUF.sound3);   
   
   %Make Recording Buffers
   if(isempty(BUF.chan1recordA))
      BUF.chan1recordA = S232('_allot16',rec_buf_duration*512);
   end
   if(isempty(BUF.chan1recordB))
      BUF.chan1recordB = S232('_allot16',rec_buf_duration*512);
   end
   if(isempty(BUF.chan2recordA))
      BUF.chan2recordA = S232('_allot16',rec_buf_duration*512);
   end
   if(isempty(BUF.chan2recordB))
      BUF.chan2recordB = S232('_allot16',rec_buf_duration*512);
   end
	S232('dpush', rec_buf_duration*512);
	S232('value', 0);
	S232('dupn', 3);
	S232('qpop16', BUF.chan1recordA);
	S232('qpop16', BUF.chan1recordB);
	S232('qpop16', BUF.chan2recordA);
	S232('qpop16', BUF.chan2recordB);
   
   %Build PLAY Channel 1 Sequence Buffer
   S232('dpush',20);
   S232('value',0);
   S232('make',0,BUF.sound3);			% 8 * 512 points
   S232('make',1,1);
   S232('make',2,BUF.zeros);			% 512 points
   S232('make',3,8184);					% 8 times
	if (isempty(BUF.playseq3))
   	BUF.playseq3 = S232('_allot16',20);
	end
   S232('qpop16',BUF.playseq3);   
   
   %Build RECORD Sequence for Double Buffering - Channel1
   S232('dpush',10);
   S232('value',0);
   S232('make',0,BUF.chan1recordA);
   S232('make',1,1);
   S232('make',2,BUF.chan1recordB);
   S232('make',3,1);
	if (isempty(BUF.recseq1))
   	BUF.recseq1 = S232('_allot16',10);
	end
   S232('qpop16',BUF.recseq1);
   
   %Build RECORD Sequence for Double Buffering - Channel2
   S232('dpush',10);
   S232('value',0);
   S232('make',0,BUF.chan2recordA);
   S232('make',1,1);
   S232('make',2,BUF.chan2recordB);
   S232('make',3,1);
	if (isempty(BUF.recseq2))
   	BUF.recseq2 = S232('_allot16',10);
	end
   S232('qpop16',BUF.recseq2);
   
   %Build PLAY Specification List for 2-Channel Play
   S232('dpush',10);
   S232('value',0);
   S232('make',0,BUF.playseq3);
   S232('make',1,0);
	if (isempty(BUF.playspec))
   	BUF.playspec = S232('_allot16',10);
	end
   S232('qpop16',BUF.playspec);
   
   %Build RECORD Specification List for 2-Channel Recording
   S232('dpush',10);
   S232('value',0);
   S232('make',0,BUF.recseq1);
   S232('make',1,BUF.recseq2);
   S232('make',2,0);
	if (isempty(BUF.recordspec))
   	BUF.recordspec = S232('_allot16',10);
	end
   S232('qpop16',BUF.recordspec);
   

%Initialize the PD1
S232('PD1clear',din);
S232('PD1srate',din,samp_per);
S232('PD1mode',din,13);
%1 = DAC1; 2 = DAC2; 3 = DAC1 and DAC2
%4 = ADC1; 8 = ADC2; 12 = ADC1 and ADC2
%15 = DUALDAC + DUALADC, hex 3 + hex C
%13 = DAC1 + DUALADC, hex 1 + hex C
S232('PD1npts',din,num_mon_pts);

%Set sequences
S232('seqplay',BUF.playspec);
S232('seqrecord',BUF.recordspec);

%Arm & Trigger the PD1
S232('PD1arm',din);
S232('PD1go',din);

%Monitor - Main Loop for Double Buffering
cycle_count = 1;
while S232('PD1status',din)
   
   %Wait for first buffers to finish loading
   rep = 0;
   while(S232('PD1status',din) &...
      S232('recseg',1) == BUF.chan1recordA & ...
      S232('recseg',2) == BUF.chan2recordA)
     	rep = rep+1;
	end
      
   S232('qpush16',BUF.chan1recordA);
   temp1(cycle_count,:) = S232('pop16');  
   S232('qpush16',BUF.chan2recordA);
   temp2(cycle_count,:) = S232('pop16');  
  
   S232('dropall');
   
   %Wait for second buffers to finish loading
   rep = 0;
   while(S232('PD1status',din) & ...
		S232('recseg',1) == BUF.chan1recordB & ...
      S232('recseg',2) == BUF.chan2recordB)
   	rep = rep+1;
   end
   
   S232('qpush16',BUF.chan1recordB);
     
   S232('qpush16',BUF.chan2recordB);
       
   S232('dropall');
   
   cycle_count = cycle_count + 1;
    
end %end WHILE loop for monitoring
S232('PA4atten',2,99);
deinit_tdt

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [] = init_tdt;

%function [] = init_tdt(din, trig_mode)
% initialize all SystemII hardware

if(S232('S2init',0 ,'INIT_SECONDARY',10000)==0)
   disp('FAILED to initialize a secondary process');
   return;
else
   disp('Initialized secondary process');
end

if(S232('APlock',100, 0 )==0)
   disp('FAILED to get AP lock for initialization');
   return;
else
   disp('AP lock');
end
if(S232('XBlock',100, 0 )==0)
   disp('FAILED to get XB lock for initialization');
   S232('APunlock',0 );                         
   disp('AP unlock');
   return;
else
   disp('XB lock');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [] = deinit_tdt

S232('PD1stop',1);
S232('PD1clear',1);
S232('trash');
S232('XBunlock',0);
S232('APunlock',0);
S232('S2close'); 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [X,Xtime] = whnoise(minfreq,maxfreq,Fs,duration)
%A script to produce noise with a flat spectrum between specified frequencies.
%Usage: [freq domain, time domain] = whnoise(min frequency, max frequency,Fs,durationor)
%durationor is used to determine length; len = duration * Fs;
%Borrowed from Kip Keller w_rnd.m

if (nargin < 3) Fs = 45000; end
if (nargin < 4) duration = 10; end

len = duration*Fs;

minfreq = round(((minfreq+1)/Fs) * len);
maxfreq = round(((maxfreq+1)/Fs) * len);
range = maxfreq-minfreq+1;

% mag spectrum = 1 between set frequencies:
mag = zeros(len,1);
mag(minfreq:maxfreq) = 50 * ones(range,1);

% random phase spectrum between set frequencies:
phase = (rand(len,1) - 0.5) * (2*pi);
% combine phase and magnitude:
X = mag .* ( (cos(phase)) + (i .* sin(phase)) );

% convert to time domain:
Xtime = real(ifft(X));

return;