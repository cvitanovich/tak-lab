% download to MII
% not yet finished

global_mii
global C_, M_;

m214x( C_.CLOCK, M_.COUNT, PULSE_COUNT );
m214x( C_.CLOCK, M_.INTERVAL, PULSE_PERIOD );
m214x( C_.CLOCK, M_.DELAY, trigger_delay );
m308x( C_.INIT, M_LEFT );
m308x( C_.INIT, M_.RIGHT );
m308x( C_.CLOCK, M_.LEFT, M_.RAMP, left_ramp );
m308x( C_.CLOCK, M_.RIGHT, M_.RAMP, right_ramp );

freq =;
m308x( C_.DATA, M_.LEFT, M_.SINE, freq, left_period );
m308x( C_.DATA, M_.RIGHT, M_.SINE, freq, right_period );

period = max( [left_period right_period] );
ramp_time = max( [left_ramp right_ramp] );
stim_time = ( ( STIM_DUR * period) + ramp_time);
m308x( C_.CLOCK, M_.LEFT, M_.FLAT, stim_time );
m308x( C_.CLOCK, M_.RIGHT, M_.FLAT, stim_time );


