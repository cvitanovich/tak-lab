function [] = deinit_all

% deinit_all
% closes all devices and
% clears un_necessary variables, arrays...
% (one man's trash is another man's gold...)

global C_
global QUES
global BUF
global VCR_

% stop the PD1 
if(S232('XBlock',100, 0)==0)
    disp('FAILED to get XBlock to stop PD1');
 else
    s232('PD1resetDSP', 1,255);
	 s232('dropall');
    s232('PD1clrsched', 1);

    S232('PD1stop',1);   
    S232('PD1clrIO',1);
    S232('XBunlock',0);
end

	% stop the MII
m110dx(C_.STOP);

	% mute the attenuators
if(S232('XBlock',100, 0)==0)
   disp('FAILED to receive XB lock');
else
	S232('PA4mute',1);
	S232('PA4mute',2);
   S232('XBunlock',0);
end


if (S232('APlock',100,0)==0)
   disp('FAILED to get APlock to deallocate buffers');
else
   S232('trash');		% coarsely
   % or more finely:
   %S232('deallot', BUF.coef);
   %S232('deallot', BUF.zeros);
   %S232('deallot', BUF.sound1);
   %S232('deallot', BUF.sound2);
   %S232('deallot', BUF.filter1);
   %S232('deallot', BUF.filter2);
   %S232('deallot', BUF.record);
   %S232('deallot', BUF.decimate);
   %S232('deallot', BUF.pre);
   %S232('deallot', BUF.post);
   %S232('deallot', BUF.seq1);
   %S232('deallot', BUF.seq2);
   %S232('deallot', BUF.playspec);
   S232('APunlock',0);
end
S232('APunlock',0);
S232('XBunlock',0);
S232('S2close');

if (QUES.useVCR)   VCR(VCR_.stop);		end

% clear MATLAB variables
clear ISI MAX_SPIKES ans az dir el err ind nHeaders playlist position;
clear preLoadScale rep stim t0;
%clear BUF C_ FN HRTF_HEAD M_ QUES REC_INFO VCR_;
