%Script quitOT
%Script for shutting down OwlTracker

S232('trash');
S232('dropall');
deinit_tdtonly;
close all;
