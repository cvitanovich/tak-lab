function [] = start_mii

%function [] = start_mii
% start MII recording spikes & outpulse

C_START = 2;
C_DATA  = 8;
M_PULSE = 3;
M_BIT   = 1;

m110dx( C_START );
m101xx( C_DATA, M_BIT, M_PULSE, 0);
