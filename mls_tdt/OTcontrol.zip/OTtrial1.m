%Script OTtrial
%OwlTracker script to collect 1 trial's worth of data
% version without double buffering

msec_start = 1000;
msec_end = trial_dur - msec_start - noi_dur;

%Allot buffers and make new noise if the settings have changed
   S232('trash');
   clear BUF;
   global BUF
	BUF = struct(...
   'playspec', [],...
   'recordspec', [],...
   'playseq1', [],...
   'playseq2', [],...
   'playseq3', [],...
   'recseq1', [],...
   'recseq2', [],...
   'sound1', [],...
   'sound2', [],...
   'sound3', [],...
   'zeros', [],...
   'chan1recordA', [],...
   'chan1recordB', [],...
   'chan2recordA', [],...
   'chan2recordB', [],...
	'outbuffer', [],...   
   'decimate', [],...
   'coef',  [],...
   'filter1', [],...
   'filter2', [],...
   'pre', [],...
   'post', []);
   
   %Make 1 ms of silence and put into BUF.zeros
   S232('dpush',(1000/REC_INFO.stim_samp_period)+1);
   S232('value',0.0);
	if (isempty(BUF.zeros))
   	BUF.zeros = S232('_allot16',(1000/REC_INFO.stim_samp_period)+1);
	end
   S232('qpop16',BUF.zeros);
   
   %Make SOUNDS   
   [temp,bpsound] = whnoise(bandlimits(1),bandlimits(2),REC_INFO.stim_samp_rate_hz,noi_dur/1000);
   bpsound = 1000*bpsound'; %MUST BE A ROW VECTOR!!!!
   % put array on stack
   S232('dpush',length(bpsound));
	S232('push16',bpsound,length(bpsound));

	%scale & duplicate
	bufMag = max([S232('maxval') abs(S232('minval'))]);
	if (bufMag > 0.0)
		S232('scale', 32000/bufMag);
   end
   S232('qwind',2,REC_INFO.stim_samp_period);
   S232('qdup');
   
   % Initialize and fill DAMA for sound1
	if (isempty(BUF.sound1))
      BUF.sound1 = S232('_allot16',length(bpsound));
   end
   S232('qpop16',BUF.sound1);
   
   % Initialize Recording Buffers
   if(isempty(BUF.chan1recordA))
      BUF.chan1recordA = S232('_allot16',REC_INFO.npts_total_play);
   end
   if(isempty(BUF.chan2recordA))
      BUF.chan2recordA = S232('_allot16',rec_buf_dur*(1000/REC_INFO.stim_samp_period)+1);
   end
	S232('dpush', REC_INFO.npts_total_play);
	S232('value', 0);
	S232('dupn', 1);
	S232('qpop16', BUF.chan1recordA);
	S232('qpop16', BUF.chan2recordA);
   
   %Build PLAY sequence for Channel 1
   S232('dpush',10);
   S232('value',0);
   S232('make',0,BUF.zeros)
   S232('make',1,msec_start);
   S232('make',2,BUF.sound1);
   S232('make',3,1);
   S232('make',4,BUF.zeros);
   S232('make',5,msec_end);
   if (isempty(BUF.playseq1))
      BUF.playseq1 = S232('_allot16',10);
   end
   S232('qpop16',BUF.playseq1);
      
   %Build PLAY specification List for 1-Channel Play
   S232('dpush',10);
   S232('value',0);
   S232('make',0,BUF.playseq1);
	if (isempty(BUF.playspec))
   	BUF.playspec = S232('_allot16',10);
	end
   S232('qpop16',BUF.playspec);

   %Build RECORD Sequence for Channel1
   S232('dpush',10);
   S232('value',0);
   S232('make',0,BUF.chan1recordA);
   S232('make',1,1);
	if (isempty(BUF.recseq1))
   	BUF.recseq1 = S232('_allot16',10);
	end
   S232('qpop16',BUF.recseq1);
   
   %Build RECORD Sequence for Channel2
   S232('dpush',10);
   S232('value',0);
   S232('make',0,BUF.chan2recordA);
   S232('make',1,1);
	if (isempty(BUF.recseq2))
   	BUF.recseq2 = S232('_allot16',10);
	end
   S232('qpop16',BUF.recseq2);
   
   
   %Build RECORD Specification List for 2-Channel Recording
   S232('dpush',10);
   S232('value',0);
   S232('make',0,BUF.recseq1);
   %S232('make',1,BUF.recseq2);
	if (isempty(BUF.recordspec))
   	BUF.recordspec = S232('_allot16',10);
	end
   S232('qpop16',BUF.recordspec);
   
info_change = 0;
   

%prepare to plot HeadTracker trace
axes(h_axes);
hold on


%Open outfile if not already open:
outfile_id = fopen(outfile,'a');
if(outfile_id < 0)
   disp(ferror(outfile_id));
end
concaten_flag = 1; %Append DAMA2DISK to existing information

%Initialize the PD1
S232('PD1clear',din);
S232('PD1fixbug',din);
%s232('PD1nstrms',din, 1, 1);
S232('PD1npts',din,REC_INFO.npts_total_play);
S232('PD1srate',din,REC_INFO.stim_samp_period);
S232('PD1mode',din,5); 			%15 = DUALDAC + DUALADC, hex 3 + hex C
											%13 = DAC1 + DUALADC, hex 1 + hec C
											%5  = DAC1 + ADC1, hex 1 + hex 4
if 0                                 
S232('PD1clrsched',din);
S232('PD1specOB', din, S232('OB',0), S232('ADC', 0));                                 
S232('PD1specIB', din, S232('IB',0), S232('DAC', 0));                                 
end                                                      

%Set sequences
S232('seqplay',BUF.playspec);
S232('seqrecord',BUF.recordspec);

%Arm & Trigger the PD1
S232('PD1arm',din);
S232('PD1go',din);

%trigger from m101 chan 0
%m101x(C_.DATA,M_.BIT,M_.PULSE,0);
%delay_msec(500);

disp(['status:' num2str(S232('PD1status',din))])

% MAIN LOOP
while S232('PD1status',din) == 2
   
pause(.05)

while (S232('APactive'))	
end 
   
   S232('qpush16',BUF.chan1recordA);
   Vx = S232('whatis',S232('topsize')-1);
   Vx = gain_horiz*volt_mult*Vx/(K*32000);
   
while (S232('APactive'))	
end 

   S232('qpush16',BUF.chan2recordA);
   Vy = S232('whatis',S232('topsize')-1);
   Vy = gain_horiz*volt_mult*Vy/(K*32000);
      
   if(Vx >= -1 & Vx <= 1 & Vy >= -1 & Vy <=1)
      AZ = (180/pi)*asin(Vx);
      EL = (180/pi)*asin(Vy);
   end
   

 S232('dropall');
   
   %plot datapts
   plot(AZ,EL,plotsymbol);
   
   %Wait for second buffers to finish loading
   %S232('PD1status',din) &...
   %while(S232('recseg',1) == BUF.chan1recordB);		% &...
%         S232('recseg',2) == BUF.chan2recordB)
   %end
   
if 0   
   S232('qpush16',BUF.chan1recordB);
   Vx = S232('whatis',S232('topsize')-1);
   Vx = gain_horiz*volt_mult*Vx/(K*32000);
     
   S232('qpush16',BUF.chan2recordB);
   Vy = S232('whatis',S232('topsize')-1);
   Vy = gain_horiz*volt_mult*Vy/(K*32000);
      
   if(Vx >= -1 & Vx <= 1 & Vy >= -1 & Vy <=1)
      AZ = (180/pi)*asin(Vx);
      EL = (180/pi)*asin(Vy);
   end
   
   plot(AZ,EL,plotsymbol);
 end  
   %S232('dropall');
   
   %plot datapts
%   plot(AZ,EL,'g.');

end			% end of status loop



mtflag = 1;
delay_msec(1000);
axes(h_axes);
hold off
return