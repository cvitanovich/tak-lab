function [err, el, az] = readScriptLoc

%function [err, el, az] = readScriptLoc
% read next LocationSection from script file

global QUES
global FN
err = 0;
clear el az

% check to be sure file is open
if QUES.scriptfileopen <= 0
   fid = fopen(FN.script, 'r');
   if fid <1
   	err = -1;
  		warning('Cannot open file in readscript');
   end
   QUES.scriptfileopen = fid;
else
   fid = QUES.scriptfileopen;
end

% read to next location section
line = '0';
while line ~= -1
   line = fgets(fid);
   if line(1) == '#';
   	if line(1:4) == '#loc'		break;	end   
   end
end
if (line == -1 | feof(fid))
	QUES.scriptEOF = 1;
   return;   
end

% read location section from script file
if line(1:10) == '#locations'
   line = '0';
   i = 0;
   loc = ftell(fid);
   while (line(1) ~= '#' & line(1) ~= -1)
      line = fgets(fid);
      lastloc = loc;
      loc = ftell(fid);
      if (line(1) ~= '#' & line(1) ~= -1)
        temp = str2num(line);
        i = i+1;
	  	  el(i) = temp(1);
     	  az(i) = temp(2);
      end
   end
end

QUES.numberoflocs = i;

if feof(fid) QUES.scriptEOF = 1;	end

% move back one line, so next trial will encounter #
if (fseek(fid,lastloc,'bof') < 0)
   err = -1;
end
