function [argout] = testScript

%function [argout] = testScript
% read next line from script file to test for end of file
% returns QUES.scriptEOF

global QUES
global FN

% check to be sure file is open
if QUES.scriptfileopen <= 0
   fid = fopen(FN.script, 'r');
   if fid <1
  		warning('Cannot open file in testscript');
   end
   QUES.scriptfileopen = fid;
else
   fid = QUES.scriptfileopen;
end

% read next line to test for feof
offset = ftell(fid);
line = fgets(fid);
if feof(fid)    QUES.scriptEOF = 1;			end
if (fseek(fid,offset,'bof') < 0)	
   warning('FAILED to return to last line in testScript');
end
argout = QUES.scriptEOF;