function [err] = ReadScriptArgs

%function [err] = ReadScriptArgs
% reads script file header argument section

global FN
global QUES
global REC_INFO
err=0;

% open script file
if QUES.scriptfileopen < 1
	fid = fopen(FN.script, 'r');
   if fid <1
      err = -1;
		warning('Cannot open file in readscript');
	end
	QUES.scriptfileopen = fid;
else
  	fid = QUES.scriptfileopen;
end
disp('reading script file arguments section');

fseek(fid,0,'bof');

% read to arguments section marker
line = '0';
while line ~= -1
   line = fgets(fid);
   if line(1) == '#';
   	if line(1:4) == '#arg'		break;	end   
   end
end

% test for arguments section
if line(1:10) == '#arguments'
   line = '0';
   while line(1) ~= '#'
	line = fgets(fid);
	[m,n]=size(line);
   if line(1) == '-'
   switch line(2)
   case {'a' , 'A'}
      switch line(3)
      case {'r' , 'R'}
         REC_INFO.ratten = str2num(line(4:n));
      case {'l' , 'L'}
         REC_INFO.latten = str2num(line(4:n));
      end
   case {'b' , 'B'}
      REC_INFO.npts_total_record = str2num(line(3:n));
   case {'c' , 'C'}
      FN.HRTF = line(4:n-2);
   case {'d' , 'D'}
      REC_INFO.depth = str2num(line(3:n));
   case {'f' , 'F'}
      REC_INFO.decimationfactor = str2num(line(3:n));
   case {'g' , 'G'}
      QUES.interstimulusgap = str2num(line(3:n));
   case {'i' , 'I'}
      QUES.usescriptfile = str2num(line(3:n));
      if QUES.usescriptfile
         FN.script = input('Enter ScriptFileName','s');
      end
   case {'l' , 'L'}
      REC_INFO.npts_total_play = str2num(line(3:n));
   case {'m' , 'M'}
      switch line(3)
      case {'a' , 'A'}		
         QUES.restrictazimuth = str2num(line(5));
         QUES.azimuthmin	= str2num(line(7:9));
			QUES.azimuthmax	= str2num(line(11:13));
         QUES.azimuthinc	= str2num(line(14:n));
      case {'e' , 'E'}		
         QUES.restrictelevation	= str2num(line(5));
			QUES.elevationmin	= str2num(line(3:n));
			QUES.elevationmax	= str2num(line(3:n));
         QUES.elevationinc	= str2num(line(3:n));
      end
   case {'o' , 'O'}
      REC_INFO.recordAD = 1;
      [m,n] = size(line);
      FN.AD1 = line(4:n-2);
   case {'p' , 'P'}
      REC_INFO.recordspikes = str2num(line(3:n));
      if REC_INFO.recordspikes
         FN.spike = input('Enter SpikeFileName','s');
      end
   case {'r' , 'R'}
      REC_INFO.nreps = str2num(line(3:n));
   case {'t' , 'T'}			%XXXXXX gain
      switch line(3)
      case '1'
      	QUES.gain1 = str2num(line(4:n));   
      case '2'
         QUES.gain2 = str2num(line(4:n));
      end
   case {'v' , 'V'}
      REC_INFO.recordAD = str2num(line(3:n));
      if REC_INFO.recordAD
         FN.AD1 = input('Enter ADFileName','s');
      end
   case {'z' , 'Z'}
      QUES.randomizestimuli = str2num(line(3:n));
   case {'1'}
      FN.sound1 = line(3:n-2);
   case {'2'}
      FN.sound2 = line(3:n-2);
   otherwise
      error('Scriptfile argument incorrect');
   end		%switch arg
   end		%if -
   end		%while not #
end			%if argument

if feof(fid) QUES.scriptEOF = 1;	end

fclose(fid);
QUES.scriptfileopen = 0;