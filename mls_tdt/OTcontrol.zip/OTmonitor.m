%Script OTMonitor

S232('PA4atten',2,99);

num_mon_pts = 2000000000;
%Allot buffers and make new noise if the settings have changed
if (info_change == 1 | mtflag ~= 0)
   
   disp('Reallocating buffers in Monitor Mode')
   mtflag = 0;
   S232('trash');
   clear BUF;
   global BUF
	BUF = struct(...
   'playspec', [],...
   'recordspec', [],...
   'playseq1', [],...
   'playseq2', [],...
   'playseq3', [],...
   'recseq1', [],...
   'recseq2', [],...
   'sound1', [],...
   'sound2', [],...
   'sound3', [],...
   'zeros', [],...
   'chan1recordA', [],...
   'chan1recordB', [],...
   'chan2recordA', [],...
   'chan2recordB', [],...
	'outbuffer', [],...   
   'decimate', [],...
   'coef',  [],...
   'filter1', [],...
   'filter2', [],...
   'pre', [],...
   'post', []);
   
   %Make 1 ms of silence and put into BUF.zeros
   S232('dpush',(1000/REC_INFO.stim_samp_period)+1);
   S232('value',0.0);
	if (isempty(BUF.zeros))
   	BUF.zeros = S232('_allot16',(1000/REC_INFO.stim_samp_period)+1);
	end
   S232('qpop16',BUF.zeros);
   
   %Make Monitor Sound   
   if(noisetype == 0)
      [temp,monbpsound] = whnoise(bandlimits(1),bandlimits(2),REC_INFO.stim_samp_rate_hz,0.1);
   elseif(noisetype == 1);
      [temp,monbpsound] = whnoise(bandlimits(1),bandlimits(2),REC_INFO.stim_samp_rate_hz,0.1);
   end
   monbpsound = 1000*monbpsound'; %MUST BE A ROW VECTOR!!!!
   % put array on stack
   S232('dpush',length(monbpsound));
   S232('push16',monbpsound,length(monbpsound));

	%scale
	bufMag = max([S232('maxval') abs(S232('minval'))]);
	if (bufMag > 0.0)
		S232('scale', 32000/bufMag);
	end
	% Initialize and fill DAMA for IB[0] (sound1)
	if (isempty(BUF.sound3))
      BUF.sound3 = S232('_allot16',length(monbpsound));
   end
   S232('qwind',2,REC_INFO.stim_samp_period);
   S232('qpop16',BUF.sound3);   
   
   %Make Recording Buffers
   if(isempty(BUF.chan1recordA))
      BUF.chan1recordA = S232('_allot16',rec_buf_duration*(1000/REC_INFO.stim_samp_period)+1);
   end
   if(isempty(BUF.chan1recordB))
      BUF.chan1recordB = S232('_allot16',rec_buf_duration*(1000/REC_INFO.stim_samp_period)+1);
   end
   if(isempty(BUF.chan2recordA))
      BUF.chan2recordA = S232('_allot16',rec_buf_duration*(1000/REC_INFO.stim_samp_period)+1);
   end
   if(isempty(BUF.chan2recordB))
      BUF.chan2recordB = S232('_allot16',rec_buf_duration*(1000/REC_INFO.stim_samp_period)+1);
   end
	S232('dpush', rec_buf_duration*(1000/REC_INFO.stim_samp_period));
	S232('value', 0);
	S232('dupn', 3);
	S232('qpop16', BUF.chan1recordA);
	S232('qpop16', BUF.chan1recordB);
	S232('qpop16', BUF.chan2recordA);
	S232('qpop16', BUF.chan2recordB);
   
   nzeros = 10;
   %Build PLAY Channel 1 Sequence Buffer
   S232('dpush',20);
   S232('value',0);
   S232('make',0,BUF.sound3);
   S232('make',1,1);
   S232('make',2,BUF.zeros);
   S232('make',3,nzeros);
   S232('make',4,BUF.sound3);
   S232('make',5,1);
   S232('make',6,BUF.zeros);
   S232('make',7,nzeros);
   S232('make',8,BUF.sound3);
   S232('make',9,1);
   S232('make',10,BUF.zeros);
   S232('make',11,nzeros);
   S232('make',12,BUF.sound3);
   S232('make',13,1);
   S232('make',14,BUF.zeros);
   S232('make',15,nzeros);
   S232('make',16,BUF.sound3);
   S232('make',17,1);
   S232('make',18,BUF.zeros);
   S232('make',19,(num_mon_pts*(REC_INFO.stim_samp_period/1000))...
      - ((5*50) + (5*nzeros)) + 1);
	if (isempty(BUF.playseq3))
   	BUF.playseq3 = S232('_allot16',20);
	end
   S232('qpop16',BUF.playseq3);   
   
   %Build RECORD Sequence for Double Buffering - Channel1
   S232('dpush',10);
   S232('value',0);
   S232('make',0,BUF.chan1recordA);
   S232('make',1,1);
   S232('make',2,BUF.chan1recordB);
   S232('make',3,1);
	if (isempty(BUF.recseq1))
   	BUF.recseq1 = S232('_allot16',10);
	end
   S232('qpop16',BUF.recseq1);
   
   %Build RECORD Sequence for Double Buffering - Channel2
   S232('dpush',10);
   S232('value',0);
   S232('make',0,BUF.chan2recordA);
   S232('make',1,1);
   S232('make',2,BUF.chan2recordB);
   S232('make',3,1);
	if (isempty(BUF.recseq2))
   	BUF.recseq2 = S232('_allot16',10);
	end
   S232('qpop16',BUF.recseq2);
   
   %Build PLAY Specification List for 2-Channel Play
   S232('dpush',10);
   S232('value',0);
   S232('make',0,BUF.playseq3);
	if (isempty(BUF.playspec))
   	BUF.playspec = S232('_allot16',10);
	end
   S232('qpop16',BUF.playspec);
   
   %Build RECORD Specification List for 2-Channel Recording
   S232('dpush',10);
   S232('value',0);
   S232('make',0,BUF.recseq1);
   S232('make',1,BUF.recseq2);
	if (isempty(BUF.recordspec))
   	BUF.recordspec = S232('_allot16',10);
	end
   S232('qpop16',BUF.recordspec);
   
      
   
	info_change = 0;
   
end

if(get(h_monitorbut,'value') == 0) return; end

%Initialize the PD1
S232('PD1clear',din);
S232('PD1srate',din,REC_INFO.stim_samp_period);
S232('PD1mode',din,13);
%15 = DUALDAC + DUALADC, hex 3 + hex C
%13 = DAC1 + DUALADC, hex 1 + hex C
S232('PD1npts',din,num_mon_pts);

%Set sequences
S232('seqplay',BUF.playspec);
S232('seqrecord',BUF.recordspec);

%Arm & Trigger the PD1
S232('PD1arm',din);
S232('PD1go',din);

%Monitor - Main Loop for Double Buffering
cycle_count = 0;
while S232('PD1status',din)
   
   %Wait for first buffers to finish loading
   while(S232('PD1status',din) &...
         S232('recseg',1) == BUF.chan1recordA &...
         S232('recseg',2) == BUF.chan2recordA)
   end
      
   S232('qpush16',BUF.chan1recordA);
   Vx = S232('whatis',S232('topsize')-1);
   Vx = gain_horiz*volt_mult*Vx/(K*32000);
     
   S232('qpush16',BUF.chan2recordA);
   Vy = S232('whatis',S232('topsize')-1);
   Vy = gain_horiz*volt_mult*Vy/(K*32000);
      
   if(Vx >= -1 & Vx <= 1 & Vy >= -1 & Vy <=1)
      AZ = (180/pi)*asin(Vx);
      EL = (180/pi)*asin(Vy);
   end
   
   S232('dropall');
   
   %Wait for second buffers to finish loading
   while(S232('PD1status',din) &...
         S232('recseg',1) == BUF.chan1recordB &...
         S232('recseg',2) == BUF.chan2recordB)
   end
   
   S232('qpush16',BUF.chan1recordB);
   Vx = S232('whatis',S232('topsize')-1);
   Vx = gain_horiz*volt_mult*Vx/(K*32000);
     
   S232('qpush16',BUF.chan2recordB);
   Vy = S232('whatis',S232('topsize')-1);
   Vy = gain_horiz*volt_mult*Vy/(K*32000);
      
   if(Vx >= -1 & Vx <= 1 & Vy >= -1 & Vy <=1)
      AZ = (180/pi)*asin(Vx);
      EL = (180/pi)*asin(Vy);
   end
   
   S232('dropall');
   
   cycle_count = cycle_count + 1;
   
   pause(0)
   if(get(h_monitorbut,'value') == 0)
      S232('PD1stop',din);
      S232('PD1clear',din);
      break
   end
   
end %end WHILE loop for monitoring
S232('PA4atten',2,ratten);

mtflag = 0;