function [] = ads_setupPD1_mono

%function [] = setupPD1_mono
% set up PD1 for single source output through HRTFs
% and single source AtoD

global REC_INFO
global FN

% get XB lock
if(S232('XBlock',100, 0)==0)
   disp('FAILED to get XBlock in SetupPD1mono');
   return;
else
%   disp('XBlock in SetupPD1mono');
end

% get AP lock
if(S232('APlock',100, 0)==0)
   disp('FAILED to get APlock in SetupPD1mono');
   return;
else
%   disp('APlock in SetupPD1mono');
end

% clear PD1
s232('PD1clear', 1);

% specify conversion params
s232('PD1srate', 1,REC_INFO.stim_samp_period);
s232('PD1nstrms', 1,1,1);			% 1 input & 1 output buffer

% setup 2 DSPs
s232('PD1resetDSP', 1,255);
s232('dropall');
s232('PD1clrsched', 1);

s232('PD1addsimp', 1,S232('DSPout',0),S232('DAC',0));	% DSP0 to DAC0
s232('PD1addsimp', 1,S232('DSPout',1),S232('DAC',1));	% DSP1 to DAC1

s232('PD1addsimp', 1,S232('IREG',0),S232('DSPin',0));	% IREG0 to DSP0
s232('PD1addsimp', 1,S232('IREG',0),S232('DSPin',1));	% IREG0 to DSP1

% for testing only:
%s232('PD1clrsched', 1);
%s232('PD1addsimp', 1,S232('IREG',0),S232('DAC',0));
%s232('PD1addsimp', 1,S232('IREG',0),S232('DAC',1));

s232('PD1specIB', 1,S232('IB',0),S232('IREG',0));			% IB0 to IREG0

% HRTF coefficients will be sent to IB1 and then to COEF0 & COEF1
% this will be specified in a packet
s232('PD1specOB', 1,S232('OB',0),S232('ADC',0));			% ADC0 to OB0

ads_Loadsound(FN.sound1,1);				% load 1st Sound

% other options under development:
%loadtone;				% testing with a tone
%loadSound_ABS;		% load sound for pupil dilation exp
%loadMATLABarray;		% testing loading MATLAB array

buildFiltbufs;			% builds 2 filter buffers for HRTF coefs

if (REC_INFO.recordAD)
   buildRecBuf;		% build Recording & Decimation Buffers
end

ads_Build1playSeq;		% build play sequence #1 & play spec list

%unlock
S232('APunlock',0);
%disp('APunlock in Setup');
S232('XBunlock',0);
%disp('XBunlock in Setup');