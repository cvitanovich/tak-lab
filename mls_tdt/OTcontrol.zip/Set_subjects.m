%Script set_subject
%Set the subject for ControlOT
val = get(h_subj,'Value');
switch val
	case 1
      subject = 'Beaker';
   case 2
      subject = 'Emily';
   case 3
      subject = 'Masa';
   case 4
      subject = 'Merton';
end