function [err] = build2PlaySeq()

%function [err] = build2PlaySeq()
% build 2 play sequences and specification list

global BUF;

err = 0;
% get lock
if(S232('APlock',100, 0)==0)
   disp('No APlock in build2PlaySeq');
   return;
else
   %disp('APlock in build2PlaySeq');
end

% build 1st play sequence
S232('dpush', 10);
S232('value',0);
S232('make',0, BUF.sound1);
S232('make',1, 1);
S232('make',2, BUF.zeros);
S232('make',3, 1);
S232('make',4, 0);
if (isempty(BUF.seq1))
	BUF.seq1 = S232('_allot16',10);
end
S232('qpop16',BUF.seq1);
   
% build 2nd play sequence
S232('dpush', 10);
S232('value',0);
S232('make',0, BUF.sound2);
S232('make',1, 1);
S232('make',2, BUF.zeros);
S232('make',3, 1);
S232('make',4, 0);
if (isempty(BUF.seq2))
	BUF.seq2 = S232('_allot16',10);
end
S232('qpop16',BUF.seq2);

% Build a play specification list
S232('dpush',10);
S232('value',0);
S232('make',0, BUF.seq1);
S232('make',1, BUF.seq2);
S232('make',2, 0);
if (isempty(BUF.playspec))
	BUF.playspec = S232('_allot16',10);
end
S232('qpop16', BUF.playspec);

% unlock
S232('APunlock', 0);
%disp('APunlock');