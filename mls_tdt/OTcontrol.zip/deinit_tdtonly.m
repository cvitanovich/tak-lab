function [] = deinit_tdtonly

S232('PD1stop',1);
S232('PD1clear',1);
S232('trash');
S232('XBunlock',0);
S232('APunlock',0);
S232('S2close'); 