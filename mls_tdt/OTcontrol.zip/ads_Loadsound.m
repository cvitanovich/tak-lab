function [] = ads_Loadsound(FileName,BufNum)

%function [] = loadSound_ABS()
% load sounds to PD1 for pupil dilation experiments
% sound filenames specified in FN

global HRTF_HEAD
global REC_INFO
global BUF
global FN

% ntaps cannot exceed 255
lines = HRTF_HEAD.nlines;
if (lines > 255)
   warning('# lines truncated to 255 in loadsound');
   lines = 255;
end

% get lock
if(S232('APlock',100, 0)==0)
   disp('No APlock in loadSound');
   return;
else
   disp('APlock in loadSound');
end

% build silence buffer, filled with zeros
zerosPts = lines;
S232('dpush', zerosPts);
S232('value', 0);
if (isempty(BUF.zeros) )
   BUF.zeros = S232('_allot16',zerosPts);
end
S232('qpop16',BUF.zeros);

% build pre- buffer, filled with zeros
S232('dropall');
prePts = HRTF_HEAD.samplingrate;			% 1 second of quiet
S232('dpush', prePts);
S232('value', 0);
if (isempty(BUF.pre) )
   BUF.pre = S232('_allot16',prePts);
end
S232('qpop16',BUF.pre);

% build post- buffer, filled with zeros
% 4 seconds of quiet after sound onset
S232('dropall');
postPts = 3.9 * HRTF_HEAD.samplingrate - zerosPts +1;	
S232('dpush', postPts);
S232('value', 0);
if (isempty(BUF.post) )
   BUF.post = S232('_allot16',postPts);
end
S232('qpop16',BUF.post);

% read the sound file from disk
S232('dropall');
S232('pushdiskf',FN.sound1);
disp(['Read sound file : ', FN.sound1]);

% Remove the DC offset
soundSize = S232('topsize');
offset = S232('average');
S232('dpush',soundSize);
S232('value',offset);
S232('swap');
S232('subtract');
%bufMax = S232('maxval');
%bufMin = S232('minval');
%bufMag = bufMax - bufMin;
%if (bufMag > 0.0)
%	S232('scale', 32000/bufMag);
%end
   
% set the number of points to play
size = S232('topsize');
S232('PD1npts', 1, size + zerosPts + prePts + postPts);
REC_INFO.npts_total_play = size + zerosPts + prePts + postPts;

%plot sound
S232 ('qdup');
tempsound = S232 ('pop16');
%plot sound trace
pdr_soundfig

S232 ('totop', 1);


% Initialize & fill DAMA for IB[0] (sound1)
if (isempty(BUF.sound1))
      BUF.sound1 = S232('_allot16',soundSize);
   end
   S232('qpop16',BUF.sound1); BUF.sound1

%unlock
S232('APunlock',0);
disp('APunlock');