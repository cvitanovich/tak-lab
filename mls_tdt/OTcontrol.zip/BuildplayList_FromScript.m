function [playlist] = buildplaylist_fromScript(dir, az, el)

%function [playlist] = buildplaylist_fromScript(dir, az, el)
% compiles list of directions to play
% from az & el supplied from ScriptFile
% requires direction matrix, az, el as argins

global QUES

if (nargin ~= 3)
   error('buildplaylist_fromScript requires 3 argins');
end

[m,nDirections] = size(dir);		% should be 2 x n_directions
if m ~= 2   
   dir = dir';
	[m,nDirections] = size(dir);		% should be 2 x n_directions
   if m ~= 2
      error('Direction matrix is ill-sized');
   end
end

% elevations first:
indEl = [];
for i = 1:length(el)
  indEl = [indEl, find(dir(1,:) == el(i))];
end

if isempty(indEl)
   error('No legal elevations found');
end

% azimuths now
indAz = [];
for i = 1:length(az)
   indAz = [indAz, find(dir(2,indEl) == az(i))];
end
   
if isempty(indAz)
   error('No legal azimuths found');
end
  
playlist = indEl(indAz);		% all legal combinations
QUES.numberoflocations = length(playlist);  