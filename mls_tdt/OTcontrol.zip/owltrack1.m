%Owltrack1.m
%Script to run Owltrack experiment
%Modified from Entire.m

clear
close all


%Parameters
subject = 'Merton';
soundcharacter = 0;
bandlimits = [2000 10000];
FMincrement = 4000;
sound_dur = 4000;
sep_dur = 700;
trial_dur = 2500;
randomize_sd = 0;
numtrials = 100;
toggletrial = 1;

recbuf_dur = 20;

REC_INFO.npts_total_play = trial_dur * 1000;
REC_INFO.decimationfactor = 3;


[BUF.record1] = BuildRecBuf(recbuf_dur*1000);
[BUF.record2] = BuildRecBuf(recbuf_dur*1000);
[BUF.outbuf,BUF.decimate] = BuildOutBuf;


return

