function [] = verifysettings

%function [] = verifysettings
% display & verify Settings

global FN
global REC_INFO
global QUES

query = '?';
while (isempty(query) == 0)
clc
% first display everything:
disp(['Experimental settings for ' date]);
disp(' ');
disp (['Repetitions           	: ',  num2str(REC_INFO.nreps)]);
disp (['recording Depth       	: ',  num2str(REC_INFO.depth)]);
disp (['interstimulus Gap     	: ', 	num2str(QUES.interstimulusgap)]);

disp(' ');
if (REC_INFO.recordAD)
	disp (['saVe AD data   ']);
   disp (['	decimateFactor	: ',  num2str(REC_INFO.decimationfactor)]);
   disp (['	AtoD file	: ', FN.AD1]);
   if (REC_INFO.recordAD == 2)	disp (['	AtoD file	: ', FN.AD2]);	end
else
	disp (['do not saVe AD data   ']);
end

disp(' ');
if (REC_INFO.recordspikes)
	disp (['record sPikes   ']);
   disp(['	Spike file	: ', FN.spikes]);
else
   disp (['do not record sPikes   ']);
end
   
%disp (['doUble polar coords	: ',  num2str(QUES.useDoublePolar)]);
disp(' ');
if (QUES.restrictazimuth)
   disp ( 'restrict azimuth (M...)');
   disp (['   minimum azimuth  	: ', num2str(QUES.azimuthmin)]);
	disp (['   maximum azimuth 	: ', num2str(QUES.azimuthmax)]);
   disp (['   azimuth inc		: ', num2str(QUES.azimuthinc)]);
else
   disp ('do not restrict azimuth (M...)');
end
if (QUES.restrictelevation)
   disp ( 'restrict elevation (M...)');
	disp (['   minimum elevation	: ', num2str(QUES.elevationmin)]);
	disp (['   maximum elevation	: ', num2str(QUES.elevationmax)]);
	disp (['   elevation inc	: ', num2str(QUES.elevationinc)]);
else
   disp ('do not restrict elevation (M...)');
end

disp(' ');
disp (['Atten Left 		: ', num2str(REC_INFO.latten)]);
disp (['Atten Right		: ', num2str(REC_INFO.ratten)]);

disp(' ');
if (QUES.usescriptfile)
   disp (['scrIpt file     	: ', FN.script]);
else
   disp ('do not use scrIpt file')
end

disp(' ');
disp (['souNd file 1   		: ', FN.sound1]);
if (QUES.numberofsoundfiles > 1)
	disp (['sound file2			: ', FN.sound2]);
end

disp(' ');
disp (['hrtf Coeff file 	: ', FN.HRTF]);

disp(' ');
if (QUES.useVCR)
   disp('use video Tape recorder');
else
   disp('do not use video Tape recorder');
end
disp('');
disp('');

query = input('Enter letter of item to change ','s');
if isempty(query) == 0	changesetting(query);  end

end