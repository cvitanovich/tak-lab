function [count, bufID] = DiskToDamaF (fileName, bufID, pos, points, flag)

%function [count, bufID] = DiskToDamaF (fileName, bufID, position, points, flag)
% reads disk file floats and dumps onto AP DAMA
% requires filename 
% if bufID provided, then must be preassigned to proper length;
% else it will allocate and return bufID
% default starting position at 'bof'
% default points is entire file
% if flag = +1 then scales to 32000 before writing to DAMA
% returns count (or -1 on error)

if isempty(pos)	   pos = 0;			end

fid = fopen(fileName, 'rb');
if fid == -1
	error(['Could not open file for reading in DISK2DAMAF ' fileName]);
end

if (fseek(fid, pos, 'bof') == -1)
	error ('Error seeking position in file in DISK2DAMAF');
end

if isempty(points) | points < 1
   [temp, count] = fread(fid,inf,'float32');
else
   [temp, count] = fread(fid, points, 'float32');
end
fclose(fid);

% get lock
if(S232('APlock',100, 0)==0)
   disp('No APlock in DisktoDamaF');
   return;
else
   disp('APlock in DisktoDamaF');
end

S232('pushf', temp(:)', count);
size = S232('topsize');
if size ~= count
   error('Pushed incorrect number of points onto the stack in DISK2DAMAF');
   count = -1;
end

if flag == 1				% scale up to 32K
   bufMag = S232('maxval') - S232('minval');
	if (bufMag > 0.0)
		S232('scale', (32000.0 / bufMag));
	else
		error('hrtf coefficient buffer magnitude is 0');
   end
end

if isempty(bufID)   bufID = S232('_allotf', size);		end
S232('qpopf', bufID);
      
%unlock
S232('APunlock',0);
disp('APunlock');