function [RecordBuf] = buildRecBuf(RecordBuf,Recpts)

%function [] = buildRecBuf()
% build recording and decimation buffers

% The RecordBuf will be used to record the AtoD data.
% The DecimateBuf will be used to store the
% decimated data before writing the data to disk.
% Decimation is necessary since the playing and
% recording must be done at the same rate.
% To manage a different recording rate, the data
% buffer will be decimated after the data has
% been collected. Decimation occurs at 1 / (2 ^ DecimationFactor).

% get AP lock
if(S232('APlock',100, 0)==0)
   disp('No APlock in BuildRecBuf');
   return;
else
%   disp('APlock in BuildRecBuf');
end

% reserve space on the stack
S232('dropall');
RecBufSize = Recpts;
S232('dpush',RecBufSize);
   
% check here for proper buffer size
size = S232('topsize');
if (size ~= RecBufSize)
   warning('Could not allocate recording buffer on stack' );
end
   
% fill AtoD recording buffer with all zeros
S232('value',0);
if (isempty(RecordBuf))
	RecordBuf = S232('_allot16',size);
end
S232('qpop16',RecordBuf);

%unlock
S232('APunlock',0);
%disp('APunlock');
