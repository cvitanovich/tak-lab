%Script OTMi2Monitor
%Use the Mi2 to produce the centering sound


%Allot buffers and make new noise if the settings have changed
if (info_change == 1 | mtflag ~= 0)
   
   disp('Reallocating buffers in Monitor Mode')
   mtflag = 0;
   S232('trash');
   clear BUF;
   global BUF
	BUF = struct(...
   'playspec', [],...
   'recordspec', [],...
   'playseq1', [],...
   'playseq2', [],...
   'playseq3', [],...
   'recseq1', [],...
   'recseq2', [],...
   'sound1', [],...
   'sound2', [],...
   'sound3', [],...
   'zeros', [],...
   'chan1recordA', [],...
   'chan1recordB', [],...
   'chan2recordA', [],...
   'chan2recordB', [],...
	'outbuffer', [],...   
   'decimate', [],...
   'coef',  [],...
   'filter1', [],...
   'filter2', [],...
   'pre', [],...
   'post', []);
   
   %Make Recording Buffers
   if(isempty(BUF.chan1recordA))
      BUF.chan1recordA = S232('_allot16',rec_buf_duration*(1000/REC_INFO.stim_samp_period)+1);
   end
   if(isempty(BUF.chan1recordB))
      BUF.chan1recordB = S232('_allot16',rec_buf_duration*(1000/REC_INFO.stim_samp_period)+1);
   end
   if(isempty(BUF.chan2recordA))
      BUF.chan2recordA = S232('_allot16',rec_buf_duration*(1000/REC_INFO.stim_samp_period)+1);
   end
   if(isempty(BUF.chan2recordB))
      BUF.chan2recordB = S232('_allot16',rec_buf_duration*(1000/REC_INFO.stim_samp_period)+1);
   end
	S232('dpush', rec_buf_duration*(1000/REC_INFO.stim_samp_period));
	S232('value', 0);
	S232('dupn', 3);
	S232('qpop16', BUF.chan1recordA);
	S232('qpop16', BUF.chan1recordB);
	S232('qpop16', BUF.chan2recordA);
	S232('qpop16', BUF.chan2recordB);
   
   %Build RECORD Sequence for Double Buffering - Channel1
   S232('dpush',10);
   S232('value',0);
   S232('make',0,BUF.chan1recordA);
   S232('make',1,1);
   S232('make',2,BUF.chan1recordB);
   S232('make',3,1);
	if (isempty(BUF.recseq1))
   	BUF.recseq1 = S232('_allot16',10);
	end
   S232('qpop16',BUF.recseq1);
   
   %Build RECORD Sequence for Double Buffering - Channel2
   S232('dpush',10);
   S232('value',0);
   S232('make',0,BUF.chan2recordA);
   S232('make',1,1);
   S232('make',2,BUF.chan2recordB);
   S232('make',3,1);
	if (isempty(BUF.recseq2))
   	BUF.recseq2 = S232('_allot16',10);
	end
   S232('qpop16',BUF.recseq2);
   
   %Build RECORD Specification List for 2-Channel Recording
   S232('dpush',10);
   S232('value',0);
   S232('make',0,BUF.recseq1);
   S232('make',1,BUF.recseq2);
	if (isempty(BUF.recordspec))
   	BUF.recordspec = S232('_allot16',10);
	end
   S232('qpop16',BUF.recordspec);
     
	info_change = 0;
   
end

%prepare to plot HeadTracker trace
axes(h_axes);
hold on

if(get(h_monitorbut,'value') == 0) return; end

%Initialize the PD1
S232('PD1clear',din);
S232('PD1srate',din,REC_INFO.stim_samp_period);
S232('PD1mode',din,12);
%15 = DUALDAC + DUALADC, hex 3 + hex C
%13 = DAC1 + DUALADC, hex 1 + hex C
S232('PD1npts',din,num_mon_pts);

%Set sequences
S232('seqrecord',BUF.recordspec);

%trigger from m101 chan 0
m101x(C_.DATA,M_.BIT,M_.PULSE,0);

%Arm & Trigger the PD1
S232('PD1arm',din);
S232('PD1go',din);

%Monitor - Main Loop for Double Buffering
cycle_count = 0;
while S232('PD1status',din)
   
   %Wait for first buffers to finish loading
   while(S232('PD1status',din) &...
         S232('recseg',1) == BUF.chan1recordA &...
         S232('recseg',2) == BUF.chan2recordA)
   end
      
   S232('qpush16',BUF.chan1recordA);
   Vx = S232('whatis',S232('topsize')-1);
   Vx = gain_horiz*volt_mult*Vx/(K*32000);
     
   S232('qpush16',BUF.chan2recordA);
   Vy = S232('whatis',S232('topsize')-1);
   Vy = gain_horiz*volt_mult*Vy/(K*32000);
      
   if(Vx >= -1 & Vx <= 1 & Vy >= -1 & Vy <=1)
      AZ = (180/pi)*asin(Vx);
      EL = (180/pi)*asin(Vy);
   end
   
   figure(2)
   plot(AZ,EL,plotsymbol);
   
   S232('dropall');
   
   %Wait for second buffers to finish loading
   while(S232('PD1status',din) &...
         S232('recseg',1) == BUF.chan1recordB &...
         S232('recseg',2) == BUF.chan2recordB)
   end
   
   S232('qpush16',BUF.chan1recordB);
   Vx = S232('whatis',S232('topsize')-1);
   Vx = gain_horiz*volt_mult*Vx/(K*32000);
     
   S232('qpush16',BUF.chan2recordB);
   Vy = S232('whatis',S232('topsize')-1);
   Vy = gain_horiz*volt_mult*Vy/(K*32000);
      
   if(Vx >= -1 & Vx <= 1 & Vy >= -1 & Vy <=1)
      AZ = (180/pi)*asin(Vx);
      EL = (180/pi)*asin(Vy);
   end
   
   figure(2)
   plot(AZ,EL,plotsymbol);
   
   S232('dropall');
   
   cycle_count = cycle_count + 1;
   
   pause(0)
   if(get(h_monitorbut,'value') == 0)
      S232('PD1stop',din);
      S232('PD1clear',din);
      break
   end
   
end %end WHILE loop for monitoring

mtflag = 0;
return

