% script OTchoose_spkr
% makes chosen speaker active and inactivates all others

for i = 1:8
	if i == spkrnum
   	set(h_spkrbut(i),'BackgroundColor',active_color);
	else
   	set(h_spkrbut(i),'BackgroundColor',front_color);
	end
end