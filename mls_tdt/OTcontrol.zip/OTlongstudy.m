%Script OTLongStudy
%OwlTracker script to collect 1 trial's worth of data

mtflag = 0;
%Allot buffers and make new noise if the settings have changed
   
   if(randsep_flag ~= 0)
      val_nse = 50 + (round(rand(1)*maxsep)*10);
   end
   
   S232('trash');
   clear BUF;
   global BUF
	BUF = struct(...
   'playspec', [],...
   'recordspec', [],...
   'playseq1', [],...
   'playseq2', [],...
   'playseq3', [],...
   'recseq1', [],...
   'recseq2', [],...
   'sound1', [],...
   'sound2', [],...
   'sound3', [],...
   'zeros', [],...
   'chan1recordA', [],...
   'chan1recordB', [],...
   'chan2recordA', [],...
   'chan2recordB', [],...
	'outbuffer', [],...   
   'decimate', [],...
   'coef',  [],...
   'filter1', [],...
   'filter2', [],...
   'pre', [],...
   'post', []);

   %Make 1 ms of silence and put into BUF.zeros
   S232('dpush',(1000/REC_INFO.stim_samp_period)+1);
   S232('value',0.0);
	if (isempty(BUF.zeros))
   	BUF.zeros = S232('_allot16',(1000/REC_INFO.stim_samp_period)+1);
	end
   S232('qpop16',BUF.zeros);
   
   %Make SOUNDS   
   if(noisetype == 0)
      [temp,bpsound] = whnoise(bandlimits(1),bandlimits(2),REC_INFO.stim_samp_rate_hz,val_nde/1000);
   elseif(noisetype == 1);
      [temp,bpsound] = whnoise(bandlimits(1),bandlimits(2),REC_INFO.stim_samp_rate_hz,val_nde/1000);
   end
   bpsound = 1000*bpsound'; %MUST BE A ROW VECTOR!!!!
   % put array on stack
   S232('dpush',length(bpsound));
	S232('push16',bpsound,length(bpsound));

	%scale
	bufMag = max([S232('maxval') abs(S232('minval'))]);
	if (bufMag > 0.0)
		S232('scale', 32000/bufMag);
	end
   
	% Initialize and fill DAMA for IB[0] (sound1)
	if (isempty(BUF.sound1))
		BUF.sound1 = S232('_allot16',length(bpsound));
   end
   S232('qpop16',BUF.sound1);
   
   % put array on stack
	S232('push16',bpsound,length(bpsound));

	%scale
	bufMag = max([S232('maxval') abs(S232('minval'))]);
	if (bufMag > 0.0)
		S232('scale', 32000/bufMag);
	end
   
	% Initialize & fill DAMA for IB[0] (sound2)
	if (isempty(BUF.sound2))
		BUF.sound2 = S232('_allot16',length(bpsound));
   end
   S232('qpop16',BUF.sound2);


   if(stim_present_flag == 0)
      %Build PLAY Channel 1 Sequence Buffer
      S232('dpush',10);
      S232('value',0);
      S232('make',0,BUF.zeros);
      S232('make',1,centsoundlength+centseplength);
      S232('make',2,BUF.sound1);
      S232('make',3,1);
      S232('make',4,BUF.zeros);
      S232('make',5,trial_duration - val_nde - ...
         centsoundlength - centseplength);
      if (isempty(BUF.playseq1))
         BUF.playseq1 = S232('_allot16',10);
      end
      S232('qpop16',BUF.playseq1);
      
      %Build PLAY Channel 2 Sequence Buffer
      S232('dpush',10);
      S232('value',0);
      S232('make',0,BUF.zeros);
      S232('make',1,val_nse + val_nde + centsoundlength + centseplength);
      S232('make',2,BUF.sound2);
      S232('make',3,1);
      S232('make',4,BUF.zeros);
      S232('make',5,trial_duration - (2*val_nde + val_nse +...
         centsoundlength + centseplength));
      S232('make',6,0);
      if (isempty(BUF.playseq2))
         BUF.playseq2 = S232('_allot16',10);
      end
      S232('qpop16',BUF.playseq2);
   end
   
   if(stim_present_flag == 1)
      %Build PLAY Channel *2* Sequence Buffer
      S232('dpush',10);
      S232('value',0);
      S232('make',0,BUF.zeros);
      S232('make',1,centsoundlength+centseplength);
      S232('make',2,BUF.sound1);
      S232('make',3,1);
      S232('make',4,BUF.zeros);
      S232('make',5,trial_duration - val_nde - ...
         centsoundlength - centseplength);
      if (isempty(BUF.playseq2))
         BUF.playseq2 = S232('_allot16',10);
      end
      S232('qpop16',BUF.playseq2);
      
      %Build PLAY Channel *1* Sequence Buffer
      S232('dpush',10);
      S232('value',0);
      S232('make',0,BUF.zeros);
      S232('make',1,val_nse + val_nde + ...
         centsoundlength + centseplength);
      S232('make',2,BUF.sound2);
      S232('make',3,1);
      S232('make',4,BUF.zeros);
      S232('make',5,trial_duration - (2*val_nde + val_nse +...
         centsoundlength + centseplength));
      S232('make',6,0);
      if (isempty(BUF.playseq1))
         BUF.playseq1 = S232('_allot16',10);
      end
      S232('qpop16',BUF.playseq1);
   end %end for randomizing stim presentation

   %Build PLAY Specification List for 2-Channel Play
   S232('dpush',10);
   S232('make',0,BUF.playseq1);
   S232('make',1,BUF.playseq2);
   S232('make',2,0);
	if (isempty(BUF.playspec))
   	BUF.playspec = S232('_allot16',10);
	end
   S232('qpop16',BUF.playspec);
   
   
	info_change = 0;
   

S232('PA4atten',1,latten);
S232('PA4atten',2,ratten);

breakflag = 0;
for ncycles = 1:100
   
   if(get(h_longstudybut,'value') == 0)
      breakflag = 1;
      break;
   end
   
   VCR(VCR_.record);
   pause(10);
   
   %Set sequences
	S232('seqplay',BUF.playspec);

	%Initialize and Trigger the PD1
	S232('PD1clear',din);
	S232('PD1srate',din,REC_INFO.stim_samp_period);
	S232('PD1npts',din,REC_INFO.npts_total_play);
   S232('PD1mode',din,3); %15 = DUALDAC + DUALADC, hex 3 + hex C
   
	%trigger from m101 chan 0
	m101x(C_.DATA,M_.BIT,M_.PULSE,0);
   
	S232('PD1arm',din);
	S232('PD1go',din);
   
   %Wait for PD1 to finish
	while(S232('PD1status',din) ~= 0)
	end

	S232('PD1stop',din);
   S232('PD1clear',din);
   VCR(VCR_.stop);
   
   delay_actual = (delay_longstudy*60 + round(120*rand(1)))/60;
   set(h_delay_longstudy_txt,'String',['Actual delay (min) = ' num2str(delay_actual)]);
   set(h_timeleft_txt,'String',['Time left (min) = ' num2str(delay_actual)]);
   t_init = clock;
   while(etime(clock,t_init) < delay_actual*60)
      if(get(h_longstudybut,'value') == 0)
         breakflag = 1;
         break;
      end
      pause(1);
      set(h_timeleft_txt,'String',['Time left (min) = ' ...
            num2str(delay_actual - (etime(clock,t_init)/60))]);
   end
   if(breakflag == 1) 
   	VCR(VCR_.stop);   
      break;
   end  
 
end

mtflag = 2;