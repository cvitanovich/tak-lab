function [] = buildFiltbufs

%function [] = buildFiltbufs
% builds 2 buffers for HRTF coefficients

global HRTF_HEAD
global BUF

% get lock
if(S232('APlock',100, 0)==0)
   disp('No APlock in buildFiltbufs');
   return;
else
   %disp('APlock in buildFiltBufs');
end

% ntaps cannot exceed 255
lines = HRTF_HEAD.nlines;
if (lines > 255)
   warning('# lines truncated to 255 in loadsound');
   lines = 255;
end

% Build packet for HRTF coeffs      
if (isempty(BUF.filter1))
   BUF.filter1 = S232('_allot16', lines);
end  
if (isempty(BUF.filter2))
   BUF.filter2 = S232('_allot16', lines);
end

%unlock
S232('APunlock',0);
%disp('APunlock');