function [] = loadSound(FileName,BufNum)

%function [] = loadSound(FileName,BufNum)
% load sound to PD1
% BufNum is 1)sound1 or 2)sound2

global HRTF_HEAD
global REC_INFO
global BUF

% ntaps cannot exceed 255
lines = HRTF_HEAD.nlines;
if (lines > 255)
   warning('# lines truncated to 255 in loadsound');
   lines = 255;
end

% get lock
if(S232('APlock',100, 0)==0)
   disp('No APlock in loadSound');
   return;
else
%   disp('APlock in loadSound');
end

% build silence buffer, filled with zeros
zerosPts = lines;
S232('dpush', zerosPts);
S232('value', 0);
if (isempty(BUF.zeros) )
   BUF.zeros = S232('_allot16',zerosPts);
end
S232('qpop16',BUF.zeros);

% read the sound file from disk
S232('dropall');
S232('pushdiskf',FileName);
disp(['Read sound file : ', FileName]);

% Remove the DC offset
soundSize = S232('topsize');
offset = S232('average');
S232('dpush',soundSize);
S232('value',offset);
S232('swap');
S232('subtract');
bufMag = max([S232('maxval') abs(S232('minval'))]);
if (bufMag > 0.0)
	S232('scale', 32000/bufMag);
end
   
% set the number of points to play
size = S232('topsize');
S232('PD1npts', 1, size + zerosPts);
REC_INFO.npts_total_play = size + zerosPts;

switch BufNum
case {1}		% Initialize & fill DAMA for IB[0] (sound1)
   if (isempty(BUF.sound1))
      BUF.sound1 = S232('_allot16',soundSize);
   end
   S232('qpop16',BUF.sound1);
case {2}		% Initialize & fill DAMA for IB[1] (sound2)
   if (isempty(BUF.sound2))
      BUF.sound2 = S232('_allot16',soundSize);
   end
   S232('qpop16',BUF.sound2);
end

%unlock
S232('APunlock',0);
%disp('APunlock');