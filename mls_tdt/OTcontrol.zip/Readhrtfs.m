function [] = readHRTFs

%function [] = readHRTFs
% read HRTF coefficient file header and loads
% coeffs to DAMA

global HRTF_HEAD
global FN
global BUF

HEADER_SIZE = 256;

%read header
[HRTF_HEAD.filetype,HRTF_HEAD.nheaders,...
    HRTF_HEAD.nchannels,HRTF_HEAD.nlines, HRTF_HEAD.samplingrate,...
    HRTF_HEAD.firstline,HRTF_HEAD.lastline,HRTF_HEAD.ndirections,...
    HRTF_HEAD.comment1, HRTF_HEAD.comment2] = mtlrh(FN.HRTF);

points = HRTF_HEAD.nchannels * HRTF_HEAD.nlines;
pos    = HRTF_HEAD.nheaders * HEADER_SIZE;

switch(HRTF_HEAD.filetype)
	case 1			% 16 bit
		BUF.coef = S232('_allot16', points);
		disk2dama16 (BUF.coef, FN.HRTF, pos);
	case 2				% 32 bit
		BUF.coef = S232('_allotf', points);
		diskToDamaF(FN.HRTF, BUF.coef, pos,[],1);
   case 3
      error('COMPLEX HRTFs! cannot do this yet');
end