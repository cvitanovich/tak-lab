function [] = w_sbhdr2(FileName)

% [] = w_sbhdr2(FileName) 
% based on w_shdr1.m
% appends SUBheader information to end of file
% writes only 2 SoundFileNames (from FN)

global FN
HDR_BLOCK_SIZE = 256;

if (nargin <1)   error('W_sbhdr1 requires FileName');		end

[fid, errmess] = fopen(FileName, 'r+', 'l');
if fid <= 0
   error(errmess);
end

% find end of file
fseek(fid, 0, 'eof');
x = ftell(fid);
offset = ftell(fid);

% write all zeros to one HDR_Block
temp = zeros(HDR_BLOCK_SIZE,1);
if(fwrite(fid, temp, 'int16') < 0)		% N_headers
  error(['FAILED to write subhdr to file ' FileName]);
end

% write soundfileNames
fseek(fid,offset,'bof');
if(fwrite(fid, FN.sound1, 'char') < 0)
   error(['FAILED to write subhdr to file ' FileName]);
end

if (isempty(FN.sound2)~=1)
  fseek(fid,offset+128,'bof');
  if(fwrite(fid, FN.sound2, 'char') < 0)
    error(['FAILED to write subhdr to file ' FileName]);
  end
end

% close the file
fclose(fid);