function [err] = loadHRTFcoefs(dir1)

%function [err] = loadHRTFcoefs(dir1)
% load HRTF coefficients to DAMA buffers

global HRTF_HEAD
global BUF
err =0;

lines = HRTF_HEAD.nlines;
if lines > 255
   warning('# lines truncated to 255 in loadHRTFcoefs');
   line = 255;
end

% get lock
if(S232('APlock',100, 0)==0)
   disp('No APlock in LoadHRTFcoefs');
   return;
else
   disp('APlock in LoadHRTFcoefs');
end

% left ear coefficients
	position = (2 * dir1) * HRTF_HEAD.nlines;
   S232('qpushpart16', BUF.coef, position, lines);
   size = S232('topsize');
   if size <> lines
      warning('left ear HRTFcoefs improperly loaded')
      err = -1;
   end
	S232('qpop16',BUF.filter1);

% right ear coefficients
	position = (2 * dir1 + 1) * HRTF_HEAD.nlines;
	S232('qpushpart16',BUF.coeff, position, lines);
   size = S232('topsize');
   if size <> lines
      warning('right ear HRTFcoefs improperly loaded')
      err = -1;
   end
	S232('qpop16',BUF.filter2);
   
%unlock
S232('APunlock',0);
disp('APunlock');
