function [playlist] = buildplaylist(dir)

%function [playlist] = buildplaylist(dir)
% compiles list of directions to play
% from restricted (or not) az & el
% randomizes order if necessary
% requires direction matrix as argin

global QUES

[m,nDirections] = size(dir);		% should be 2 x n_directions
if m ~= 2   
   dir = dir';
	[m,nDirections] = size(dir);		% should be 2 x n_directions
   if m ~= 2
      error('Direction matrix is ill-sized');
   end
end


if QUES.restrictelevation
   tempEl = QUES.elevationmin:QUES.elevationinc:QUES.elevationmax;
   nElevations = length(tempEl);
   indEl = [];
   for i = 1:nElevations
      indEl = [indEl, find(dir(1,:) == tempEl(i))];
   end
else
   indEl = 1:nDirections;
end

if length(indEl) <= 0
   error('No legal elevations found');
end
   
   
   
if QUES.restrictazimuth
   tempAz = QUES.azimuthmin:QUES.azimuthinc:QUES.azimuthmax;
   nAzimuths = length(tempAz);
   indAz = [];
   for i = 1:nAzimuths
      indAz = [indAz, find(dir(2,indEl) == tempAz(i))];
   end
else
   indAz = indEl;
end
   
if length(indAz) <= 0
   error('No legal azimuths found');
end
  
playlist = indEl(indAz);		% all legal combinations
QUES.numberoflocations = length(playlist);  

if (QUES.randomizestimuli & isempty(playlist) ~=1)
   rand('state',sum(100*clock));
   playlist = playlist(randperm(nDirections));
end
