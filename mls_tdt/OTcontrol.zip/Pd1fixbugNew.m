function [] = PD1FixBugNew (din)

%function [] = PD1FixBugNew(din)
% depends on QUES.MIItrig to identify trigger source

global QUES

if isempty(din) din = 1;	end

C_DATA 	= 8;
M_PULSE	= 3;
M_BIT 	= 1;

% get lock
if(S232('XBlock',100, 0)==0)
   disp('No XBlock in PD1fixbugNew');
   return;
else
%    disp('XBlock in PD1fixbugNew');
end

DUALADC = s232('PD1export','DUALADC',0);

s232('PD1mode',din,DUALADC);
s232('PD1npts',din,600);
s232('PD1srate',din,200);
s232('PD1arm',din);

if QUES.MIItrig
   s232('PD1strig',din);
   m101x(C_DATA,M_BIT,M_PULSE,0);
else
   s232('PD1go',din);
   
   % while PD1status(din)
end

%unlock
S232('XBunlock',0);
%disp('XBunlock');