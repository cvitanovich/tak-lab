% just working on MII
globals_MII
init_MII

freq = 200;				%Hz
left_period = 20;		%usecs
right_period = 20;	%usecs

m100x( C_.INIT );

%m300x( C_.INIT );
%m300x( C_.MODE, M_.SOURCE1, M_.SOURCE2 );

m308x( C_.INIT, M_.LEFT );
m308x( C_.INIT, M_.RIGHT );
%m308x( C_.CLOCK, M_.LEFT, M_.RAMP, left_ramp);
%m308x( C_.CLOCK, M_.RIGHT, M_.RAMP, right_ramp);

% for playing tones
m308x( C_.DATA, M_.LEFT, M_.SINE, freq, left_period);
m308x( C_.DATA, M_.RIGHT, M_.SINE, freq, right_period);

m308x( C_.CLOCK, M_.LEFT, M_.RAMP, left_ramp);
m308x( C_.CLOCK, M_.RIGHT, M_.RAMP, right_ramp);



% for loading files
%m308x( C_.DATA, M_.LEFT, M_.LOAD, left_array, left_period);
%m308x( C_.DATA, M_.RIGHT, M_.LOAD, right_array, right_period);

%trigger from m101 chan 0
m101x(C_.DATA,M_.BIT,M_.PULSE,0)