function [err] = ChangeSetting(choice)

%function [err] = ChangeSetting(choice)
% changes settigns for tdt experiments

global FN
global QUES
global REC_INFO

err = 0;
disp(' ');
switch (choice)
	case {'a' , 'A'}
		REC_INFO.latten = input('Enter the left attenuation ');
		REC_INFO.ratten = input('Enter the right attenuation ');

	case {'b' , 'B'}
		REC_INFO.npts_total_play = input('Enter the recording buffer size ');

	case {'c' , 'C'}
		FN.HRTF = input('Enter hrtf file name ', 's');

	case {'d' , 'D'}
		REC_INFO.depth = input ('Enter the recording depth ');

	case {'f' , 'F'}
		REC_INFO.decimationfactor = input('Enter the decimation factor ');
      
   case {'g' , 'G'}
		QUES.interstimulusgap = input('Enter the interstimulus gap (100 msec min) ');
      
   case {'i' , 'I'}
      if QUES.usescriptfile
         QUES.usescriptfile = 0;
      else
         QUES.usescriptfile = 1;
			FN.script = input('Enter the script file name ', 's');
         [err] = readscriptargs;
      end
      
	case {'l' , 'L'}
		REC_INFO.npts_total_play = input('Enter the length (duration) of sound ');
      
   case {'m' , 'M'}
		ch = input('Azimuth or Elevation [ae] ','s');
		if (ch == 'a' | ch == 'A')
         if QUES.restrictazimuth
            QUES.restrictazimuth = 0;
         else
            QUES.restrictazimuth = 1;
				QUES.azimuthmin = input('Enter the azimuth minimum ');
				QUES.azimuthmax = input('Enter the azimuth maximum ');
				QUES.azimuthinc = input('Enter the azimuth increment ');
         end
		elseif (ch == 'e' | ch == 'E')
         if QUES.restrictelevation
            QUES.restrictelevation = 0;
         else
            QUES.restrictelevation = 1;
				QUES.elevationmin = input('Enter the elevation minimum ');
				QUES.elevationmax = input('Enter the elevation maximum ');
				QUES.elevationinc = input('Enter the elevation increment ');
         end
      end
      
	case {'n' , 'N'}
		FN.sound1 = input('Enter the 1st sound file name ', 's');

	case '2'
		FN.sound2 = input('Enter the 2nd sound file name ', 's');

	case {'o' , 'O'}
		FN.AD = input('Enter the AtoD output file name ', 's');

	case {'p' , 'P'}
      if REC_INFO.recordspikes
         REC_INFO.recordspikes = 0;
      else
         REC_INFO.recordspikes = 1;
         FN.spikes = input('Enter the spike file name ','s');
      end
      
   case {'r' , 'R'}
		REC_INFO.nreps = input('Enter the number of repetitions ');
      
   case {'s' , 'S'}
      if REC_INFO.recordspikes
         FN.spikes = input('Enter the spike file name ','s');
      end
      
   case {'t' , 'T'}
      if (QUES.useVCR)
         QUES.useVCR = 0;
      else
         QUES.useVCR = 1;
      end
      
   case {'u' , 'U'}
      if QUES.usedoublepolar
         QUES.usedoublepolar = 0;
      else
         QUES.usedoublepolar = 1;
      end
      
        
   case {'v' , 'V'}
      REC_INFO.recordAD = input('Enter number of AtoD channels (0,1,2)');
      switch REC_INFO.recordAD
      case {0}
         FN.AD1 = [];
         FN.AD2 = [];
      case {1}
         REC_INFO.decimationfactor = input('Enter decimation Factor ');
         FN.AD1 = input('Enter the 1st AtoD file name ','s');
      case {2}
         REC_INFO.decimationfactor = input('Enter decimation Factor ');
         FN.AD1 = input('Enter the 1st AtoD file name ','s');
         FN.AD2 = input('Enter the 2nd AtoD file name ','s');       
      end

end