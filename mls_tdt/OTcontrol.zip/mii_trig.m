function [] = mii_trig(port);

% function [] = mii_trig(port)
%
% starts the M110d
% and produces a trigger from the MII 101A port
% default port == 0

global C_;
global M_;

if (nargin ==0 | port <0)
   port = 0;
end

init_mii;
m110dx(C_.START);
m101x(C_.DATA,M_.BIT,M_.PULSE,port);