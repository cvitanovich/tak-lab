%Script OTsetinfo
%Set all the information for ControlOT

%Set some parameters
trial_dur = 6000; %ms
rec_buf_dur = 100; %ms

%Subject name:
val = get(h_subj,'Value');
switch val
	case 1
      subject = 'Merton    ';
   case 2
      subject = 'Nacianzus     ';
end

%Output Filename:
outfile = get(h_outfile,'String');

%Noise Duration:
noi_dur = str2num(get(h_noisedur_e,'String'));

%Limits of bandpass
bandlimits = sscanf(get(h_bandlimits,'String'),'%f');

%Headtracker Axis Limits & Plot
xlimits = sscanf(get(h_xlimits,'String'),'%f');
ylimits = sscanf(get(h_ylimits,'String'),'%f');
axes(h_axes);
axis([xlimits(1) xlimits(2) ylimits(1) ylimits(2)]);
set(h_axes,'XTick',xlimits(1):(xlimits(2)-xlimits(1))/10:xlimits(2),...
   'YTick',ylimits(1):(ylimits(2)-ylimits(1))/10:ylimits(2),...
   'XTickLabel',[num2str((xlimits(1):(xlimits(2)-xlimits(1))/10:xlimits(2))')],...
   'YTickLabel',[num2str((ylimits(1):(ylimits(2)-ylimits(1))/10:ylimits(2))')]);

%Attenuation
latten = str2num(get(h_latten,'String'));
ratten = str2num(get(h_ratten,'String'));

%Gain
gain_horiz = str2num(get(h_gain_horiz,'String'));
gain_vert  = str2num(get(h_gain_vert ,'String'));

% mute attenuators
if(S232('APlock',100, 0 )==0)
   disp('FAILED to get AP lock for initialization');
end
if(S232('XBlock',100, 0 )==0)
   disp('FAILED to get XB lock for initialization');
   S232('APunlock',0 );                         
   disp('AP unlock');
end

S232('PA4mute',1);
S232('PA4mute',2);

S232('PA4atten',1,latten);
S232('PA4atten',2,ratten);

% unlock
S232('XBunlock',0);
S232('APunlock',0);


REC_INFO.latten = latten;
REC_INFO.ratten = ratten;
REC_INFO.nreps = 1;
REC_INFO.numstreams = 2;
REC_INFO.stim_samp_rate_hz = 30000;
REC_INFO.stim_samp_period = 1000000/30000;
REC_INFO.decimationfactor = 4;
REC_INFO.data_samp_rate_hz = 30000/(2^REC_INFO.decimationfactor);
REC_INFO.data_samp_period = 1000000/REC_INFO.data_samp_rate_hz;
REC_INFO.npts_total_play = trial_dur*1000/REC_INFO.stim_samp_period;
REC_INFO.npts_total_record = trial_dur*1000/REC_INFO.data_samp_period;

din = 1;
volt_mult = 1;
K = 2.86;

info_change = 1;