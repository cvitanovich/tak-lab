%avi_entire.m
% script to control everything

% initialize internal variables
preLoadScale = .2;
MAX_SPIKES = 1024;
nHeaders = 0;

% initialize global variables
globals;
globals_mii;

% get & verify all parameters

SetDefaults;
ReadScriptArgs;
choicefig = ads_settings_good;
uiwait(choicefig);

if (QUES.useVCR)
   VCR(VCR_.record);
	t0 = clock;			% start clock
end

init_tdt;

% mute attenuators
if(S232('XBlock',100, 0)==0)
   disp('FAILED to get XB lock to mute attenuators');
else
	S232('PA4mute',1);
	S232('PA4mute',2);
   S232('XBunlock',0);
end

%initialize MII
init_mii;

%read HRTF coefficients to array
readHRTFs;
dir = mtlrdir(FN.HRTF,HRTF_HEAD.ndirections);
%convert coordinates to double polar
dir = sph2dbl(dir);

% build list of direction indices from which to play sound
[playlist] = buildplaylist(dir);

%set attenuators
if(S232('XBlock',100, 0)==0)
   disp('FAILED to get XB lock to set attenuators');
else
	S232('PA4atten',1,REC_INFO.latten);
	S232('PA4atten',2,REC_INFO.ratten);
   S232('XBunlock',0);
end

if (QUES.useVCR)
	while(etime(clock,t0) < 5)
	% wait for VCR to start up and record opening screen   
	end
	VCR(VCR_.pause);
end

% setup & zero out data arrays

%create figure in position
figure;
set (gcf, 'position', [0 500 600 200], 'menubar', 'none', 'numbertitle', 'off');
subplot (1,2,2); subplot (1,2,1)

% start main loop here:
trial = 0;
while (QUES.usescriptfile == 1 & QUES.scriptEOF == 0)
   trial = trial+1;
   disp(['Trial # ' num2str(trial)]);
   if (QUES.usescriptfile == 1)    
      if(readScriptSrc < 0)				% read source section
         warning('Error reading script file source section.');
      end
      if QUES.scriptEOF		break;	end
		[err, el, az] = readScriptLoc;		% read LocationsSection
      if (err < 0)   warning('Error reading script file location section.');	end
      
		[playlist] = buildplaylist_fromScript(dir, az, el);
   end
   if (isempty(playlist))      
      warning('The playlist is empty');
   	break;   
   end
%XXX   


ads_SetupPD1_mono;	      						% setupPD1

% write (or append) headers to data files
   if (nHeaders == 0)
      if (REC_INFO.recordspikes > 0)   w_Lhdr4(FN.spikes);   end
      switch REC_INFO.recordAD
      case {0}
      case {1}	
         w_Lhdr4(FN.AD1);
      case {2}
         w_Lhdr4(FN.AD1);
         w_Lhdr4(FN.AD2);
      end
   elseif (QUES.writesubheaders > 0)
      if (REC_INFO.recordspikes > 0)   w_sbhdr2(FN.spikes);   end
      switch REC_INFO.recordAD
      case {0}
      case {1}	
         w_sbhdr2(FN.AD1);
      case {2}
         w_sbhdr2(FN.AD1);
         w_sbhdr2(FN.AD2);
      end
   end
   nHeaders = nHeaders +1;
   
   % set up plots & arrays
   if REC_INFO.recordspikes
   	spiketimes = zeros(QUES.numberoflocations, REC_INFO.nreps, MAX_SPIKES);
	end

 % now go through each location in the playlist
	for stim = [1:QUES.numberoflocations]
   % get the az and el
    ind = playlist(stim);
    el = dir(1,ind);
    az = dir(2,ind);
    % load coefs into FiltBufs
    if(S232('APlock',100, 0)==0)
       disp('FAILED to get APlock for filling FiltBufs');
    else
       % left ear
       position = ((ind-1)*2) * HRTF_HEAD.nlines;
       S232('qpushpart16',BUF.coef,position,HRTF_HEAD.nlines);
       S232('qpop16',BUF.filter1);
      % right ear 
       position = ((ind-1)*2 + 1) * HRTF_HEAD.nlines;
       S232('qpushpart16',BUF.coef,position,HRTF_HEAD.nlines);
       S232('qpop16',BUF.filter2);
       S232('APunlock',0);
    end
    
    % play the sounds nReps times
    totalSpikes = 0;
    for rep = [1:REC_INFO.nreps]
       % start VCR
      if (QUES.useVCR)	VCR(VCR_.pause);	end	% unpause VCR
       
        % start clock
		 t0 = clock;

       %%XXXX could insert stuff to choose habituating spkr
       
       if(S232('APlock',100, 0)==0)
        	disp('FAILED to get APlock in repetitions loop');
       else
           
          if(S232('XBlock',100, 0) ==0)
           disp('FAILED to get XBlock in repetitions loop');
        	 else
           % load left ear coefs
           S232('qpush16',BUF.filter1)
           S232('scale',1/32760);		%%%XXX
           S232('PreLoadRaw',1,S232('DSPid',0)','MONO','STACK','','',preLoadScale,preLoadScale,1);
           % load right ear coefs
           S232('qpush16',BUF.filter2)
           S232('scale',1/32760);		%%%XXX
           S232('PreLoadRaw',1,S232('DSPid',1),'MONO','STACK','','',preLoadScale,preLoadScale,1);
         

           % force sound to start at the beginning
           S232('seqplay',BUF.playspec);
                    
           if (REC_INFO.recordAD)		% specify recording buffer
             S232('record',BUF.record);
           end
         
           if (QUES.MIItrig)
             S232('PD1arm',1);
             S232('pfireall');
             S232('PD1strig',1); 
             mii_trig(0);				% trigger MII (and m110d)
             
             t1 = clock;
             % wait for PD1 to finish playing sound
             while (S232('PD1status',1))
                while (etime(clock,t1) < 1)		end
                set (gcf, 'color', [1 1 0])
             end
             
          
             %XXXXX pause to collect AD data
             pause(5);
             
             if (REC_INFO.recordAD)		% write decimated buffer to disk
                S232('qpush16',BUF.record);
                S232('decimate',REC_INFO.decimationfactor);
                S232('qdup');
                temptrace = S232 ('pop16');
                S232 ('totop', 1);
                pause (.2);
                
                %XXXXX insert: to plot A2D trace
                subplot (1,2,2); plot (temptrace);set (gca, 'fontsize', 7);title (['Trial number 'num2str(trial)], 'fontsize', 7);                
                pause (.3);
                
                S232('qpop16',BUF.decimate);
                S232('dama2disk16',BUF.decimate,FN.AD1,1);		% final arg is concatenate flag
             end
             
          else		% without trigger
             S232('PD1arm',1);
             S232('PD1go',1);
             status1 =0;  status2 =0;
             while (status1 ==0 | status2 ==0)
                status1 = S232('ppausestat',1);
                status2 = S232('ppausestat',2);
             end
             if (REC_INFO.recordAD)		% write decimated buffer to disk
                S232('qpush16',BUF.record);
                S232('decimate',REC_INFO.decimationfactor);
                S232('qpop16',BUF.decimate);
                S232('dama2disk16',BUF.decimate,FN.AD1,1);		% final arg is concatenate flag
             end
        end
          
          S232('APunlock',0);
          S232('XBunlock',0);
          
          if (REC_INFO.recordspikes)
             delay_msec(100);		% continue to end of sound
             m110dx(C_.STOP);
             %%% XXX check out the following
             spikebuf = zeros(MAX_SPIKES,1);
             spikes = m110dx(C_.DATA, MAX_SPIKES/2, spikebuf);
             totalSpikes = totalSpikes+spikes;
             W_spks(FN.spikes, spikebuf, stim, rep);
             if (spikes > 0)
                spiketimes(stim,rep,1:spikes) = spikebuf;
             end
          end
 
         end	% end of XBlock
      end		% end of APlock
      
      if (QUES.useVCR)	
         delay_msec(2000);
         VCR(VCR_.pause);		% pause VCR
      end
      set (gcf, 'color', [.8 .8 .8])
		while (etime(clock,t0) < QUES.interstimulusgap/1000)		end		      %delay for desired ISI(secs)
    end		%% end of repetitions
    
 if (REC_INFO.recordspikes)	% write number of headers to spikes file
    w_Nhdrs(FN.spikes);
 end
 switch (REC_INFO.recordAD)			% write number of headers to AD file
 case {1}
    w_Nhdrs(FN.AD1);
 case {2}
    w_Nhdrs(FN.AD1);
    w_Nhdrs(FN.AD2);
 end
 
end		% end of playlist

if (TestScript)   break;	end

end		% end of scriptFile

if QUES.scriptfileopen		% close and zero scriptfile
   fclose(QUES.scriptfileopen);
   QUES.scriptfileopen = 0;
   QUES.scriptEOF = 0;
end


deinit_all;

if (QUES.useVCR)   VCR(VCR_.stop);		end
